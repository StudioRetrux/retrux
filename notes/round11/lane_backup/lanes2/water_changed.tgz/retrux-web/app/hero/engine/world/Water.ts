import * as THREE from "three";
import { WATER } from "../config";
import { GLSL_COMMON, GLSL_ENV } from "../shaders/chunks";
import type { SharedUniforms } from "../uniforms";
import {
  EXTRA_PROJECTORS,
  GLSL_EXTRA_PROJECTORS,
  GLSL_PLATE_GRADE,
  GLSL_PLATE_MIST,
  GLSL_PLATE_OCCLUSION,
  type ExtraProjectorBinding,
  type PlateOcclusionUniforms,
} from "./PlateEnvironment";

/**
 * The mirror-ray length at uv, filtered: a manual 2x2 bilinear lookup on texel centres (invalid taps, L <= 0, skipped),
 * and across an edge (max > 1.25 min) the nearest reflector instead of a mean. A single nearest texel made the re-aimed
 * lookup jump row by row wherever L jumps (a floe's reflection next to the sky's): long broken horizontal hairlines and
 * dashes under the near floes at every in-between camera (pop, release, intro; QC round 9, hold-sweep MAJOR).
 */
const mirrorLGLSL = (P: string, p: string) => /* glsl */ `
float ${p}MirrorL(vec2 uv) {
  vec2 t = u${P}DepthTexel;
  vec2 st = uv / t - 0.5;
  vec2 i0 = floor(st);
  vec2 f = st - i0;
  vec2 b = (i0 + 0.5) * t;
  vec4 L = vec4(textureLod(u${P}Depth, b, 0.0).b, textureLod(u${P}Depth, b + vec2(t.x, 0.0), 0.0).b,
                textureLod(u${P}Depth, b + vec2(0.0, t.y), 0.0).b, textureLod(u${P}Depth, b + t, 0.0).b);
  vec4 ok = step(1e-4, L);
  vec4 w = vec4((1.0 - f.x) * (1.0 - f.y), f.x * (1.0 - f.y), (1.0 - f.x) * f.y, f.x * f.y) * ok;
  float ws = w.x + w.y + w.z + w.w;
  if (ws < 1e-4) return 0.0;
  vec4 Lm = mix(vec4(1e9), L, ok);
  float mn = min(min(Lm.x, Lm.y), min(Lm.z, Lm.w));
  float mx = max(max(L.x * ok.x, L.y * ok.y), max(L.z * ok.z, L.w * ok.w));
  return mx > mn * 1.25 ? mn : dot(w, L) / ws;
}
`;

/** The lake's mirror-point re-aim (see plateMirrorPoint) for each extra projector. */
const GLSL_EXTRA_MIRROR = EXTRA_PROJECTORS.map(
  (e) => /* glsl */ `
#ifdef ${e.define}
${mirrorLGLSL(e.P, e.p)}
vec3 ${e.p}MirrorPoint(vec3 P) {
  vec3 Cp = u${e.P}CamPos;
  vec3 dir = normalize(P - cameraPosition);
  vec3 Pp = P;
  for (int i = 0; i < 2; i++) {
    vec4 c = u${e.P}ViewProjF * vec4(Pp, 1.0);
    vec2 uv = clamp(c.xy / c.w * 0.5 + 0.5, vec2(0.0), vec2(1.0));
    float L = min(${e.p}MirrorL(uv), 4000.0);
    if (L <= 0.0) break;
    vec3 X = P + dir * L;
    Pp = Cp + (X - Cp) * ((Cp.y - P.y) / max(Cp.y - X.y, 1e-3));
  }
  return Pp;
}
#endif`,
).join("");

/** Adds each extra projector's lake sample to (acc, wsum) and its good coverage to extraCover (offs, lodX in scope). */
const GLSL_WATER_PROJECTOR_BLEND = EXTRA_PROJECTORS.map(
  (e) => /* glsl */ `
#ifdef ${e.define}
    if (u${e.P}DepthOn > 0.5 && u${e.P}Mix > 0.001) {
      vec3 kpw = vWorldPos;
      vec4 kclip = u${e.P}ViewProjF * vec4(vWorldPos, 1.0);
      float visK = 1.0;
      float awayK = distance(cameraPosition, u${e.P}CamPos);
      if (awayK > 0.02) {
        vec3 mp = ${e.p}MirrorPoint(vWorldPos);
        vec4 mc = u${e.P}ViewProjF * vec4(mp, 1.0);
        vec2 muv = mc.xy / mc.w * 0.5 + 0.5;
        float behindK = -(u${e.P}View * vec4(mp, 1.0)).z - (${e.p}DepthAt(clamp(muv, vec2(0.0), vec2(1.0))) * 1.06 + 0.8);
        visK = 1.0 - smoothstep(0.0, 2.5, behindK);
        bool straight = false;
        if (behindK > 0.0) {
          vec2 suv = kclip.xy / kclip.w * 0.5 + 0.5;
          straight = -(u${e.P}View * vec4(vWorldPos, 1.0)).z - (${e.p}DepthAt(clamp(suv, vec2(0.0), vec2(1.0))) * 1.06 + 0.8) <= 0.0;
        }
        if (straight) visK = 1.0;
        else {
          kpw = mp;
          kclip = mc;
        }
      }
      // No fill of its own (visK weights it out where it cannot see the point).
      vec2 k = kclip.xy / kclip.w * 0.5 + 0.5;
      vec2 ke = min(k, 1.0 - k);
      float inK = smoothstep(-0.005, 0.035, min(ke.x, ke.y)) * step(0.0, kclip.w);
      // The rest projector's "raised" test: where the surface this projector saw at the lookup stands above the water,
      // the lake point is hidden behind it, however close the depths. The x1.06 + 0.8 m tolerance and the 2.5 m ramp let
      // a lookup that landed on a near rock or floe paint it on the water beside it (QC round 6, release with the pointer
      // at an edge: a dark rock-coloured slab beside the left rock, a translucent copy of a floe's end).
      if (awayK > 0.02) {
        float kdz = ${e.p}DepthAt(clamp(k, vec2(0.0), vec2(1.0)));
        float kfz = -(u${e.P}View * vec4(kpw, 1.0)).z;
        vec3 kseen = u${e.P}CamPos + (kpw - u${e.P}CamPos) * (kdz / max(kfz, 1e-3));
        visK *= 1.0 - smoothstep(0.05, 0.12, kseen.y - kpw.y) * (1.0 - smoothstep(40.0, 60.0, kfz));
      }
      float wK = u${e.P}Mix * visK * inK;
      extraCover += u${e.P}Mix * inK * visK;
      if (wK > 0.0005) {
        vec2 kc = clamp(k, vec2(0.0005), vec2(0.9995));
        vec2 kq = clamp(k + offs, vec2(0.0005), vec2(0.9995));
        // The ripple-bent lookup must land on the water (<p>SeenY), not on a rock or floe just in front of the lake point.
        kq = mix(kq, kc, max(step(0.05, ${e.p}SeenY(kq) - vWorldPos.y), step(${e.p}DepthAt(kq), ${e.p}DepthAt(kc) * 0.92 - 0.3)));
        acc += textureLod(u${e.P}Plate, kq, lodX).rgb * (u${e.P}Gain / uPlateGain) * wK;
        wsum += wK;
      }
    }
#endif`,
).join("");

/**
 * Round 11, user-priority round (WATER lane): the artist's water, reproduced (`LAKE_R12`, the default lake on the baked
 * environment; `?envlake=plate` keeps the re-aimed plate lake, `?envlake=mirror` the ENV lane's mirror model).
 *
 * The Cycles water (forensics 3.3) is a white conductor mirror whose normal is the Bump node (strength 1, distance 0.07,
 * filter width 1) of a 2-stop B-spline ColorRamp of a 3D fBm Noise Texture (scale 3, detail 4, roughness 0.5, lacunarity 2,
 * normalized) on object coordinates. Cycles evaluates the height at P, P + dPdx and P + dPdy (the pixel's ray differentials)
 * and builds N' = normalize(|det| N - 0.07 sign(det) surfgrad). This port:
 * - Cycles' own Perlin noise and fBm, bit for bit (hash_uint3, grad3, fade, tri_mix, 0.982 scale): the numpy twin of this code
 *   matches Blender's own noise values to 3e-6 and its ColorRamp exactly (WORK tools/cyc_noise.py, gn_noise.py), so the
 *   wavelets near the camera are the Cycles render's own pattern, fixed on the water (nothing swims when the camera moves).
 * - The same finite differences per octave at the pixel centre, each octave split into the share that is coherent over the
 *   pixel (the visible streak texture) and the incoherent rest (a blur), from a simulation of Cycles' 64 Blackman-Harris
 *   filtered samples per pixel (tools/octave_sim.py, engine_model_sim.py: the per-row elevation / azimuth spreads of this model
 *   are within ~10-15 % of the simulated Cycles pixels from 13 m to 73 m).
 * - The reflected ray is looked up in LakeMirror's planar mirror of the real scene (baked meshes, sky, live clouds) with a
 *   short parallax search on the mirror path length: a tilted ray from the lake point reaches a near floe or rock long before
 *   the mirror camera's ray in the same direction would (the floes' and rocks' reflections stay attached, as in Cycles).
 */
const GLSL_LAKE_R12 = /* glsl */ `
uniform mat4 uMirrorViewProj;   // the hero reflection's mirror camera (RenderPipeline.mirrorViewProj)
uint lkRot(uint x, uint k) { return (x << k) | (x >> (32u - k)); }
// Cycles util/hash.h hash_uint3 (Jenkins lookup3 final()); an int is cast to uint as in C (two's complement).
uint lkHash(ivec3 k) {
  uint a = 0xdeadbf08u;
  uint b = a;
  uint c = a;
  c += uint(k.z + 1073741824) - 1073741824u;
  b += uint(k.y + 1073741824) - 1073741824u;
  a += uint(k.x + 1073741824) - 1073741824u;
  c ^= b; c -= lkRot(b, 14u);
  a ^= c; a -= lkRot(c, 11u);
  b ^= a; b -= lkRot(a, 25u);
  c ^= b; c -= lkRot(b, 16u);
  a ^= c; a -= lkRot(c, 4u);
  b ^= a; b -= lkRot(a, 14u);
  c ^= b; c -= lkRot(b, 24u);
  return c;
}
float lkGrad(uint hash, vec3 f) {
  uint h = hash & 15u;
  float u = h < 8u ? f.x : f.y;
  float vt = (h == 12u || h == 14u) ? f.x : f.z;
  float v = h < 4u ? f.y : vt;
  return ((h & 1u) != 0u ? -u : u) + ((h & 2u) != 0u ? -v : v);
}
// Cycles perlin_3d. z2 = false on the near plane: its object z is 0, so the upper lattice layer has weight fade(0) = 0.
float lkPerlin(vec3 p, bool z2) {
  vec3 fl = floor(p);
  vec3 f = p - fl;
  ivec3 I = ivec3(fl);
  vec3 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  float a = mix(mix(lkGrad(lkHash(I), f), lkGrad(lkHash(I + ivec3(1, 0, 0)), f - vec3(1.0, 0.0, 0.0)), u.x),
                mix(lkGrad(lkHash(I + ivec3(0, 1, 0)), f - vec3(0.0, 1.0, 0.0)), lkGrad(lkHash(I + ivec3(1, 1, 0)), f - vec3(1.0, 1.0, 0.0)), u.x), u.y);
  if (!z2) return a;
  float b = mix(mix(lkGrad(lkHash(I + ivec3(0, 0, 1)), f - vec3(0.0, 0.0, 1.0)), lkGrad(lkHash(I + ivec3(1, 0, 1)), f - vec3(1.0, 0.0, 1.0)), u.x),
                mix(lkGrad(lkHash(I + ivec3(0, 1, 1)), f - vec3(0.0, 1.0, 1.0)), lkGrad(lkHash(I + ivec3(1, 1, 1)), f - vec3(1.0)), u.x), u.y);
  return mix(a, b, u.z);
}
// perlin_3d inside one lattice cell from its corner hashes (lower layer ha: 000, 100, 010, 110; upper hb: 001, 101, 011, 111).
float lkCell(vec3 f, uvec4 ha, uvec4 hb, bool z2) {
  vec3 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  float a = mix(mix(lkGrad(ha.x, f), lkGrad(ha.y, f - vec3(1.0, 0.0, 0.0)), u.x),
                mix(lkGrad(ha.z, f - vec3(0.0, 1.0, 0.0)), lkGrad(ha.w, f - vec3(1.0, 1.0, 0.0)), u.x), u.y);
  if (!z2) return a;
  float b = mix(mix(lkGrad(hb.x, f - vec3(0.0, 0.0, 1.0)), lkGrad(hb.y, f - vec3(1.0, 0.0, 1.0)), u.x),
                mix(lkGrad(hb.z, f - vec3(0.0, 1.0, 1.0)), lkGrad(hb.w, f - vec3(1.0)), u.x), u.y);
  return mix(a, b, u.z);
}
// The noise at p, p + ox and p + oy (the Bump node's three heights). When all three fall in one lattice cell (the coarse
// octaves, nearly always) the cell's corner hashes are computed once; otherwise three full evaluations. Same values.
vec3 lkPerlin3(vec3 p, vec3 ox, vec3 oy, bool z2) {
  vec3 fl = floor(p);
  if (all(equal(floor(p + ox), fl)) && all(equal(floor(p + oy), fl))) {
    ivec3 I = ivec3(fl);
    uvec4 ha = uvec4(lkHash(I), lkHash(I + ivec3(1, 0, 0)), lkHash(I + ivec3(0, 1, 0)), lkHash(I + ivec3(1, 1, 0)));
    uvec4 hb = z2 ? uvec4(lkHash(I + ivec3(0, 0, 1)), lkHash(I + ivec3(1, 0, 1)), lkHash(I + ivec3(0, 1, 1)), lkHash(I + ivec3(1, 1, 1))) : uvec4(0u);
    vec3 f = p - fl;
    return vec3(lkCell(f, ha, hb, z2), lkCell(f + ox, ha, hb, z2), lkCell(f + oy, ha, hb, z2));
  }
  return vec3(lkPerlin(p, z2), lkPerlin(p + ox, z2), lkPerlin(p + oy, z2));
}
// Per octave (unit lattice frequency), as functions of the footprint L in lattice units (tools/octave_sim.py): the coherent
// share of the pixel-mean finite-difference slope along one axis (relative to the octave's slope rms), the averaging factor
// of the other axis' footprint, and the rms of a single sample's finite difference.
float lkCoh(float L) { float x = L / 0.95; return 1.0 / (1.0 + x * x); }
float lkAvg(float L) { float x = max(L - 0.3, 0.0) / 2.2; return inversesqrt(1.0 + pow(x, 1.3)); }
float lkFd(float L) { float x = L / 0.567; return pow(1.0 + x * x * x, -1.0 / 3.0); }
// The bump at lake point Pw (three.js world) with the pixel footprint vectors dPx, dPy (world, one screen pixel). kDof widens
// the coherence footprint by the lake's DOF blur (in pixels), as averaging over the blur circle does. Returns the perturbed
// normal (three.js) and, in sig, the incoherent slope rms (per metre of height per metre) along the screen x / y footprints.
vec3 lkBump(vec3 Pw, vec3 dPx, vec3 dPy, float kDof, out vec2 sig) {
  // Blender coordinates (x, -z, y), then the object coordinates of the plane Cycles shows there (Plane.013, 1.7 mm higher,
  // covers Plane.011 from y 11.92 m on).
  vec3 pb = vec3(Pw.x, -Pw.z, Pw.y);
  bool farP = pb.y > 11.920909;
  vec3 co = farP ? vec3(pb.x, pb.y - 34.2286, 0.10754) : vec3(pb.x, pb.y, 0.0);
  vec3 dcx = vec3(dPx.x, -dPx.z, 0.0);
  vec3 dcy = vec3(dPy.x, -dPy.z, 0.0);
  float Lx0 = length(dcx.xy);
  float Ly0 = length(dcy.xy);
  float amp = 0.2534194;   // 0.5 * 0.982 / (1 + 0.5 + 0.25 + 0.125 + 0.0625)
  float f = 3.0;
  float nc = 0.0, hx = 0.0, hy = 0.0, vx = 0.0, vy = 0.0;
  for (int i = 0; i < 5; i++) {
    float Lx = Lx0 * f;
    float Ly = Ly0 * f;
    float Tx = lkFd(Lx);
    float Ty = lkFd(Ly);
    float cx = lkCoh(Lx * kDof) * lkAvg(Ly * kDof);
    float cy = lkCoh(Ly * kDof) * lkAvg(Lx * kDof);
    // Octaves whose coherent share is negligible only add their variance (no noise evaluation).
    if (max(cx, cy) > 0.01) {
      vec3 n3 = lkPerlin3(co * f, dcx * f, dcy * f, farP);
      nc += amp * n3.x;
      hx += amp * min(cx / Tx, 1.0) * (n3.y - n3.x);
      hy += amp * min(cy / Ty, 1.0) * (n3.z - n3.x);
    }
    // Each Cycles sample takes its finite differences over the COMPACT ray differential: an isotropic footprint of radius
    // ~ distance x pixel angle (= the across footprint Lx0), not the elongated pixel (WORK tools/step_sim.py: this, and only
    // this, reproduces Cycles' share of rays near the horizon at every row). So a sample sees nearly the true slope of every
    // octave coarser than ~1 cm; the pixel's mean is the coherent share above, the rest spreads the pixel's rays.
    float Tr = lkFd(Lx);
    float s = amp * f * 0.6888;   // the octave's slope rms per axis (Perlin slope rms 0.6888 per lattice unit)
    vx += max(Tr * Tr - cx * cx, 0.0) * s * s;
    vy += max(Tr * Tr - cy * cy, 0.0) * s * s;
    amp *= 0.5;
    f *= 2.0;
  }
  // ColorRamp (B-spline, 0 black, 1 white) slope at the noise value: 0.5 + n (1 - n).
  float n = 0.5 + nc;
  float rp = 0.5 + n * (1.0 - n);
  sig = rp * sqrt(vec2(vx, vy));
  // svm_node_set_bump on the plane (normal +z), Blender coordinates.
  vec3 Rx = vec3(dcy.y, -dcy.x, 0.0);   // cross(dcy, z)
  vec3 Ry = vec3(-dcx.y, dcx.x, 0.0);   // cross(z, dcx)
  float det = dot(dcx, Rx);
  vec3 sg = (rp * hx) * Rx + (rp * hy) * Ry;
  vec3 No = normalize(abs(det) * vec3(0.0, 0.0, 1.0) - 0.07 * sign(det) * sg);
  return vec3(No.x, No.z, -No.y);
}
// Normal CDF (logistic approximation, |error| < 0.01) and density.
float lkPhi(float x) { return 1.0 / (1.0 + exp(-1.702 * x)); }
// (lab calibration: the parts of the last lkReflect)
vec3 lkDbgU;
vec3 lkDbgH;
float lkDbgPc;
float lkDbgSH;
float lkPdf(float x) { return 0.3989423 * exp(-0.5 * x * x); }
// One stratum of the pixel's rays: the ray from P in direction dir (its share of the pixel's elevation spread: boxE rad of
// elevation, sA rad of azimuth), marched front to back along its projection in the mirror target with partial coverage:
// the ray reaches a surface seen at distance D beyond P at the fraction D / (t + D) of the way from uv0 to dir's vanishing
// point (the mirror camera sees it from t + D); "how far past the surface the ray is, in steps" is the coverage, so a grazing
// ray's hit / miss blends instead of flipping from row to row (the pixel's ~64 Cycles samples are spread over the pixel and
// in azimuth). Each step takes the target with a box filter: the stratum's elevation span and the azimuth spread, both
// scaled by the step's parallax fraction, plus the screen footprint (gx, gy: the target uv's derivatives x the DOF).
vec3 lkRay(vec2 uv0, vec2 p0, float t, vec3 dir, float boxE, float sA, vec2 gx, vec2 gy, int steps) {
  vec4 c1 = uEnvMirrorViewProj * vec4(dir, 0.0);
  if (c1.w <= 1e-4) return lakeSky(dir);
  vec2 p1 = c1.xy / c1.w;
  vec2 duv = (p1 - p0) * 0.5;
  float e = asin(clamp(dir.y, -1.0, 1.0));
  vec2 hz = normalize(dir.xz + vec2(1e-6, 0.0));
  const float DE = 0.02;
  vec4 cu = uEnvMirrorViewProj * vec4(hz.x * cos(e + DE), sin(e + DE), hz.y * cos(e + DE), 0.0);
  vec2 J = (cu.xy / max(cu.w, 1e-4) - p1) * (0.5 / DE);
  vec2 hz2 = vec2(hz.x * cos(DE) - hz.y * sin(DE), hz.x * sin(DE) + hz.y * cos(DE));
  vec4 ca = uEnvMirrorViewProj * vec4(hz2.x * cos(e), sin(e), hz2.y * cos(e), 0.0);
  vec2 K = (ca.xy / max(ca.w, 1e-4) - p1) * (0.5 / DE);
  float lj = max(length(J), 1e-6);
  float lk = max(length(K), 1e-6);
  vec3 acc = vec3(0.0);
  float T = 1.0;
  float sPrev = 0.0;
  // Steps dense near the lake point (s = (i / steps)^2): a floe or rock a metre or two beyond it sits at s ~ 0.03-0.1.
  for (int i = 1; i <= 16; i++) {
    if (i > steps || T < 0.02) break;
    float u = float(i) / float(steps);
    float sv = u * u;
    float ds = sv - sPrev;
    sPrev = sv;
    // Depth first (plain bilinear); the filtered colour only where the ray reaches a surface (w > 0).
    vec2 uvS = clamp(uv0 + duv * sv, vec2(0.0005), vec2(0.9995));
    float k = max(1.0 - t / max(textureLod(uEnvMirror, uvS, 0.0).a, 1e-3), 0.0);
    float w = i == steps ? 1.0 : clamp((sv - k) / ds + 0.5, 0.0, 1.0);
    if (w < 1.0 && i < steps) {
      // Secant: the surface seen here is reached at s = k; when that comes before the next step, test it there. A thin
      // floe face just beyond the lake point covers only a few target rows of the path, between two steps.
      float uN = float(i + 1) / float(steps);
      if (k > sv && k < uN * uN) {
        vec2 uvK = clamp(uv0 + duv * k, vec2(0.0005), vec2(0.9995));
        float k2 = max(1.0 - t / max(textureLod(uEnvMirror, uvK, 0.0).a, 1e-3), 0.0);
        if (k >= k2 - 0.01) {
          vec2 dyK = (J / lj) * sqrt(dot(gy, gy) + pow(boxE * k * lj, 2.0));
          vec2 dxK = (K / lk) * sqrt(dot(gx, gx) + pow(3.46 * sA * k * lk, 2.0));
          acc += T * (1.0 - w) * textureGrad(uEnvMirror, uvK, dxK, dyK).rgb;
          T *= w;
        }
      }
    }
    if (w > 0.0) {
      vec2 dy = (J / lj) * sqrt(dot(gy, gy) + pow(boxE * sv * lj, 2.0));
      vec2 dx = (K / lk) * sqrt(dot(gx, gx) + pow(3.46 * sA * sv * lk, 2.0));
      acc += T * w * textureGrad(uEnvMirror, uvS, dx, dy).rgb;
      T *= 1.0 - w;
    }
  }
  return acc;
}
// Inverse of lkPhi.
float lkPhiInv(float p) { p = clamp(p, 1e-4, 1.0 - 1e-4); return log(p / (1.0 - p)) / 1.702; }
// The reflection of lake point P (camera distance t) through the Cycles bump: N = the pixel's coherent normal, sig = the
// incoherent slope rms (screen x / y). The pixel's rays spread in elevation (2 x 0.07 x slope) around the coherent ray and in
// azimuth (that x tan of the grazing angle); Cycles lifts every ray that would leave under the horizon to
// dot(Ng, R) = min(0.9 Iz, 0.01) (ensure_valid_specular_reflection): that share looks along the water at the horizon (the far
// floes', the iceberg's and the shore's faces: the reflection columns). So: the clamped share at the horizon elevation, plus
// the rest as a wide vertical lookup centred on the mean elevation of the unclamped rays.
vec3 lkReflect(vec2 uv0, vec2 gx, vec2 gy, float t, vec3 V, vec3 N, vec2 sig, vec2 extra, out float sHit) {
  uv0 += extra;
  vec4 c0 = uEnvMirrorViewProj * vec4(-V.x, V.y, -V.z, 0.0);
  vec2 p0 = c0.xy / max(c0.w, 1e-4);
  vec3 rc = reflect(-V, N);
  float mu = asin(clamp(rc.y, -1.0, 1.0));
  vec2 hz = normalize(rc.xz + vec2(1e-6, 0.0));
  float sigE = max(2.0 * 0.07 * sig.y, 1e-4);
  float sinA = clamp(V.y, 0.002, 0.99);
  float sigA = 2.0 * 0.07 * sig.x * sinA / sqrt(1.0 - sinA * sinA);
  float emin = asin(min(0.9 * sinA, 0.01));
  float pc = lkPhi((emin - mu) / sigE);
  sHit = pc;
  // The unclamped rays in 3 strata of equal share (conditional quantiles 1/6, 1/2, 5/6; boxes between 0, 1/3, 2/3, 1).
  float b1 = mu + sigE * lkPhiInv(pc + (1.0 - pc) / 3.0);
  float b2 = mu + sigE * lkPhiInv(pc + (1.0 - pc) * 2.0 / 3.0);
  float top = max(mu + 2.5 * sigE, b2 + 0.01);
  vec3 col = vec3(0.0);
  for (int k = 0; k < 3; k++) {
    float lo = k == 0 ? emin : (k == 1 ? b1 : b2);
    float hi = k == 0 ? b1 : (k == 1 ? b2 : top);
    float q = mu + sigE * lkPhiInv(pc + (1.0 - pc) * (float(k) + 0.5) / 3.0);
    float eq = clamp(q, lo, hi);
    vec3 d = vec3(hz.x * cos(eq), sin(eq), hz.y * cos(eq));
    col += lkRay(uv0, p0, t, d, max(hi - lo, 1e-4), sigA, gx, gy, 7);
  }
  col *= (1.0 - pc) / 3.0;
  lkDbgU = col;
  lkDbgPc = pc;
  lkDbgH = vec3(0.0);
  if (pc > 0.004) {
    vec3 dirH = vec3(hz.x * cos(emin), sin(emin), hz.y * cos(emin));
    lkDbgH = lkRay(uv0, p0, t, dirH, 0.0, sigA, gx, gy, 10);
    lkDbgSH = 0.0;
    col += pc * lkDbgH;
  }
  return col;
}
// v3 (default; v2 above with ?lkv=2): the pixel's rays split by the first obstacle behind the lake point. The v2 strata (3
// fixed quantile rays) could not resolve the share of a pixel's rays that hit the first face behind P: Cycles, just in front
// of a far floe, sends ~40-60 % of them into its sunlit face (WORK an/farR4.png, col_prof.py: columns 0.9-1.9 vs v2 0.4-0.9).
// 1. The horizon ray (elevation emin, where Cycles lifts every ray that would leave under the horizon) finds the surface
//    nearest P in the reflected azimuth: d beyond P.
// 2. Its top: the hit point raised by 0.15-5.6 m stays on the obstacle while the mirror target sees nothing behind it.
// 3. Every ray of the pixel below the top's elevation from P, e_top = atan(h / d), hits that face (the clamped ones too):
//    the share F = Phi((e_top - mu) / sigE) takes the face's colour, its footprint the face's height x the azimuth spread.
// 4. The rest go over it: one short parallax march at their conditional mean elevation, box-filtered over their spread.
uniform vec3 uMirrorCamPos;   // LakeMirror's mirrored camera (the target's alpha is the path length from it)
float lkK(vec2 uv, float t) {
  return max(1.0 - t / max(textureLod(uEnvMirror, clamp(uv, vec2(0.0005), vec2(0.9995)), 0.0).a, 1e-3), 0.0);
}
vec2 lkProj(vec3 X) {
  vec4 c = uEnvMirrorViewProj * vec4(X, 1.0);
  return c.xy / max(c.w, 1e-4) * 0.5 + 0.5;
}
vec3 lkReflect3(vec2 uv0, vec2 gx, vec2 gy, float t, vec3 V, vec3 N, vec2 sig, vec2 extra, vec3 P, out float sHit) {
  uv0 += extra;
  vec4 c0 = uEnvMirrorViewProj * vec4(-V.x, V.y, -V.z, 0.0);
  vec2 p0 = c0.xy / max(c0.w, 1e-4);
  vec3 rc = reflect(-V, N);
  float mu = asin(clamp(rc.y, -1.0, 1.0));
  vec2 hz = normalize(rc.xz + vec2(1e-6, 0.0));
  float sigE = max(2.0 * 0.07 * sig.y, 1e-4);
  float sinA = clamp(V.y, 0.002, 0.99);
  float sigA = 2.0 * 0.07 * sig.x * sinA / sqrt(1.0 - sinA * sinA);
  float emin = asin(min(0.9 * sinA, 0.01));
  float pc = lkPhi((emin - mu) / sigE);
  vec3 dirH = vec3(hz.x * cos(emin), sin(emin), hz.y * cos(emin));
  // Target uv per radian of azimuth around the horizon direction (the azimuth spread's direction and scale in the target).
  vec2 K0;
  float lk0;
  {
    const float DA = 0.02;
    vec4 cH = uEnvMirrorViewProj * vec4(dirH, 0.0);
    vec2 hz2 = vec2(hz.x * cos(DA) - hz.y * sin(DA), hz.x * sin(DA) + hz.y * cos(DA));
    vec4 ca = uEnvMirrorViewProj * vec4(hz2.x * cos(emin), sin(emin), hz2.y * cos(emin), 0.0);
    K0 = (ca.xy / max(ca.w, 1e-4) - cH.xy / max(cH.w, 1e-4)) * (0.5 / DA);
    lk0 = max(length(K0), 1e-6);
  }
  // 1. The horizon ray's first surface (s: the parallax fraction d / (t + d); sky = none). Steps of ~1 target texel along its
  // path (uv is linear in s), up to 24: a far floe's face is 1-4 texel rows tall in the target (10 quadratic steps stepped
  // over it on every other row of lake). Long paths (near water, big rocks) take bigger steps. A soft front-to-back
  // coverage (how far past the surface the step is, in steps): the ray grazes a gently sloping shore (s ~ k), where a hard
  // hit / miss flipped from row to row (v3c / v3d: horizontal stripes on the far-left water).
  vec4 c1 = uEnvMirrorViewProj * vec4(dirH, 0.0);
  vec2 duv = (c1.xy / max(c1.w, 1e-4) - p0) * 0.5;
  float nH = clamp(ceil(length(duv * uEnvMirrorSize)), 6.0, 24.0);
  float ds = 1.0 / nH;
  float rows = uEnvMirrorSize.y;
  float Tr = 1.0;
  vec3 accC = vec3(0.0);
  float accS = 0.0;
  float accW = 0.0;
  for (int i = 1; i <= 24; i++) {
    if (float(i) > nH || Tr < 0.03) break;
    float sv = float(i) * ds;
    vec2 uvS = uv0 + duv * sv;
    float k = lkK(uvS, t);
    if (k >= 0.995) continue;
    float w = clamp((sv - k) / ds + 0.5, 0.0, 1.0);
    if (w <= 0.0 && k < sv + ds) {
      // Secant: the surface seen here is reached at s = k, before the next step (a thin face just beyond P).
      vec2 uvK = uv0 + duv * k;
      if (k >= lkK(uvK, t) - 0.01) {
        uvS = uvK;
        w = 1.0;
      }
    }
    if (w > 0.0) {
      // The face's own colour where the march met it: the texel row (a far floe's face is ~1 row; a filtered lookup mixed in
      // the background above its top edge), across the azimuth spread at its distance. Not the lake's DOF: the screen blur
      // of a column is not a blur of the face in the mirror target.
      float dI = t * k / max(1.0 - k, 1e-3);
      vec2 uvA = vec2(uvS.x, (floor(uvS.y * rows) + 0.5) / rows);
      vec2 dxF = (K0 / lk0) * (1.73 * sigA * dI / (t + dI)) * lk0;
      vec3 cI = textureGrad(uEnvMirror, clamp(uvA, vec2(0.0005), vec2(0.9995)), dxF, vec2(0.0, 0.05 / rows)).rgb;
      float a = Tr * w;
      accC += a * cI;
      accS += a * k;
      accW += a;
      Tr *= 1.0 - w;
    }
  }
  float cov = accW;
  float sH = cov > 0.01 ? accS / cov : 1.0;
  sHit = sH;
  float F = pc;
  float Fface = pc;
  vec3 cFace = vec3(0.0);
  float hTop = 0.0;
  if (cov > 0.01) {
    cFace = accC / cov;
    float d = t * sH / max(1.0 - sH, 1e-3);
    vec3 X = P + dirH * d;
    // 2. The obstacle's top: probes at doubling heights; "on" while the target sees a surface no farther than the probe.
    // The probes on the face also give its colour up its height (the march met it at its foot, often darker than the sunlit
    // face and rim the pixel's rays see over its whole height); each weighted by the height it stands for.
    float hOn = 0.0;
    float hOff = 0.12;
    vec3 accP = cFace * 0.12;
    float accPw = 0.12;
    for (int j = 0; j < 7; j++) {
      vec3 Xq = X + vec3(0.0, hOff, 0.0);
      vec4 q = textureLod(uEnvMirror, clamp(lkProj(Xq), vec2(0.0005), vec2(0.9995)), 0.0);
      if (q.a > distance(uMirrorCamPos, Xq) * 1.005 + 0.25) break;
      accP += q.rgb * hOff;
      accPw += hOff;
      hOn = hOff;
      hOff *= 2.0;
    }
    {
      float hM = 0.5 * (hOn + hOff);
      vec3 Xq = X + vec3(0.0, hM, 0.0);
      vec4 q = textureLod(uEnvMirror, clamp(lkProj(Xq), vec2(0.0005), vec2(0.9995)), 0.0);
      if (q.a > distance(uMirrorCamPos, Xq) * 1.005 + 0.25) hOff = hM;
      else {
        accP += q.rgb * (hM - hOn);
        accPw += hM - hOn;
        hOn = hM;
      }
    }
    hTop = 0.5 * (hOn + hOff);
    cFace = accP / accPw;
    // 3. Every ray below the top's elevation from P hits the face (the clamped ones too).
    float eTop = atan(hTop + emin * d, d);
    Fface = max(lkPhi((eTop - mu) / sigE), pc);
  }
  // The horizon rays that met nothing see the far field at the horizon.
  vec4 cE = textureLod(uEnvMirror, clamp(uv0 + duv, vec2(0.0005), vec2(0.9995)), 0.0);
  vec3 cFar = cE.a > 59000.0 ? lakeSky(dirH) : cE.rgb;
  F = cov * Fface + (1.0 - cov) * pc;
  vec3 col = cov * Fface * cFace + (1.0 - cov) * pc * cFar;
  lkDbgH = cov > 0.01 ? cFace : cFar;
  lkDbgPc = F;
  lkDbgSH = hTop;
  lkDbgU = vec3(0.0);
  if (F < 0.995) {
    // 4. The rays over the obstacle (the Gaussian above e_top) in two strata of equal share, each looked up at its conditional
    // median and box-filtered between its quantile bounds. The upper box ends at the 90 % quantile: a box out to mu + 2.5 sigma
    // spread the thin upper tail evenly and gave the sky the weight of the massif (far-left water 1.4-1.5x Cycles; Cycles'
    // far-left lake is barely brighter than its flat mirror of the massif).
    float eLo = mu + sigE * lkPhiInv(F);
    float eMid = mu + sigE * lkPhiInv(F + 0.5 * (1.0 - F));
    float eHi = max(mu + sigE * lkPhiInv(F + 0.9 * (1.0 - F)), eMid + 0.002);
    for (int k = 0; k < 2; k++) {
      float lo = k == 0 ? eLo : eMid;
      float hi = k == 0 ? eMid : eHi;
      float eq = clamp(mu + sigE * lkPhiInv(F + (1.0 - F) * (k == 0 ? 0.25 : 0.7)), lo, hi);
      vec3 dR = vec3(hz.x * cos(eq), sin(eq), hz.y * cos(eq));
      lkDbgU += lkRay(uv0, p0, t, dR, max(hi - lo, 1e-4), sigA, gx, gy, 4);
    }
    lkDbgU *= 0.5;
    col += (1.0 - F) * lkDbgU;
  }
  return col;
}
#ifdef LK_HGT
// v4 (default with the heightfield; v3 above with ?lkv=3): the low rays' obstacles from the static max-mip heightfield
// (LakeHeight) instead of the target march. v3's march stepped over thin faces on some rows and overshot them on others, so the
// face and its colour flipped from row to row (WORK an/hstripe_modes*.png: horizontal stripes from the low hold camera).
uniform highp sampler2D uLkHgt;   // highest surface (world y) per texel; level L = maxima of 2^L x 2^L texels
uniform vec4 uLkHgtG;             // x: grid x origin, y: grid z at row 0 (rows toward -z), z: 1 / cell (1/m), w: size (texels)
uniform float uLkHgtTop;          // top level of the walk
#ifdef LK_HALF
uniform sampler2D uLkWalk;        // the walk term at half resolution (Water.renderWalk)
uniform vec2 uLkWalkInv;          // 1 / the main target's size (px)
#ifdef LK_WALKREPROJ
uniform mat4 uLkWalkVP;           // the camera's view-projection when the walk was drawn (LakeSchedule)
#endif
#endif
#ifdef LK_CACHE
uniform highp sampler2D uLkCache; // the reflection term (lkReflect4) cached while the camera is still (Water.renderCache)
uniform float uLkCacheOn;         // 1 when the cache holds this frame's camera, DOF, mirror and walk
#endif
#ifdef LK_CACHEPASS
uniform vec2 uLkZero;             // (0, 0) at run time: the cache pass's "no bend", not a constant the compiler could fold
#endif
float lkWalkIt;                   // (lab) iterations of the last walk
float lkHits;                     // (lab) obstacles met
float lkWalkD = 1.0;              // (lab) the first face's parallax fraction d / (t + d) (1: none)
float lkWalkE = 0.0;              // (lab) the final horizon elevation (rad)
vec4 lkDbgE = vec4(0.0);          // (lab) the horizon lookup: uv, a / 60000, luma
// The heightfield's surface height, bilinear (level 0).
float lkHgtAt(vec2 xz) {
  vec2 g = vec2(xz.x - uLkHgtG.x, uLkHgtG.y - xz.y) * uLkHgtG.z;
  return textureLod(uLkHgt, g / uLkHgtG.w, 0.0).r;
}
// The normal CDF with honest tails (tanh form, |error| < 3e-4; lkPhi's logistic overstates Phi(-3) 4x, which gave tall far
// faces several times their share of rays from the near water).
float lkPhiT(float x) { return 0.5 + 0.5 * tanh(0.7978846 * (x + 0.044715 * x * x * x)); }
// Mean elevation of the pixel's rays (Gaussian mu, sigE) between ea and eb; the first band also holds the share lifted to
// emin = ea (Cycles' ensure_valid_specular_reflection).
float lkBandMean(float ea, float eb, float mu, float sigE, float Fa, float Fb, bool first) {
  float pa = lkPdf((ea - mu) / sigE);
  float pb = lkPdf((eb - mu) / sigE);
  float lifted = first ? Fa : 0.0;
  float share = first ? Fb : Fb - Fa;
  return clamp((lifted * ea + mu * (Fb - Fa) - sigE * (pb - pa)) / max(share, 1e-5), ea, eb);
}
// The obstacle part (the walk): rgb = the share-weighted colours of the faces met, a = the share of the pixel's rays they take
// (0: nothing rose above the horizon ray). Independent of time (static bump, static scene) and of the ring waves: the
// half-resolution pass (LK_HALF, Water.renderWalk) draws it only when the camera moved.
vec4 lkWalkTerm(float t, vec3 V, vec3 N, vec2 sig, vec3 P) {
  vec3 rc = reflect(-V, N);
  float mu = asin(clamp(rc.y, -1.0, 1.0));
  vec2 hz = normalize(rc.xz + vec2(1e-6, 0.0));
  float sigE = max(2.0 * 0.07 * sig.y, 1e-4);
  float sinA = clamp(V.y, 0.002, 0.99);
  float sigA = 2.0 * 0.07 * sig.x * sinA / sqrt(1.0 - sinA * sinA);
  float emin = asin(min(0.9 * sinA, 0.01));
  float pc = lkPhiT((emin - mu) / sigE);
  // The walk takes the pixel's coherent azimuth (the bumped reflection's): the column edges come out wavy, as Cycles' (v4b,
  // the flat azimuth: straight, hard-edged columns; ?lkhaz=0).
#if LK_HAZ == 1
  vec2 hz0 = hz;
#else
  vec2 hz0 = normalize(-V.xz + vec2(1e-6, 0.0));
#endif
  vec3 dirH = vec3(hz0.x * cos(emin), sin(emin), hz0.y * cos(emin));
  // Target uv per radian of azimuth around the horizon direction (the azimuth spread's footprint at a face).
  vec2 K0;
  {
    const float DA = 0.02;
    vec4 cH = uEnvMirrorViewProj * vec4(dirH, 0.0);
    vec2 hz2 = vec2(hz0.x * cos(DA) - hz0.y * sin(DA), hz0.x * sin(DA) + hz0.y * cos(DA));
    vec4 ca = uEnvMirrorViewProj * vec4(hz2.x * cos(emin), sin(emin), hz2.y * cos(emin), 0.0);
    K0 = (ca.xy / max(ca.w, 1e-4) - cH.xy / max(cH.w, 1e-4)) * (0.5 / DA);
  }
  // The horizon profile seen from P along that azimuth: a quadtree walk of the heightfield (a cell the current horizon ray
  // clears at its entry, being lowest there, is skipped whole; one it may reach is split) with the ray starting at Cycles'
  // lifted elevation emin. Every texel whose surface rises above the current horizon raises it (its top seen from P: bilinear
  // samples into it, continuous as P moves): the pixel's rays between the old and the new horizon elevation hit that face,
  // looked up in the target at the heights they reach there. All obstacles in one consistent pass: when a near floe sinks
  // under the horizon ray, the share it gave up goes to what is behind it.
  float ic = uLkHgtG.z;
  float cell = 1.0 / ic;
  float Ng = uLkHgtG.w;
  vec2 g0 = vec2(P.x - uLkHgtG.x, uLkHgtG.y - P.z) * ic;
  vec2 dg = vec2(hz0.x, -hz0.y) * ic;
  dg = vec2(abs(dg.x) < 1e-5 ? 1e-5 : dg.x, abs(dg.y) < 1e-5 ? 1e-5 : dg.y);
  vec2 idg = 1.0 / dg;
  ivec2 st = ivec2(step(0.0, dg));
  int top = int(uLkHgtTop + 0.5);
  float y0 = P.y;
  float m = tan(emin);
  float Fc = 0.0;
  float Fa = 0.0;
  float eC = emin;
  vec3 acc = vec3(0.0);
  float d = 0.05;
  int L = 0;
  float hits = 0.0;
  float dFirst = -1.0;
  lkDbgH = vec3(0.0);
  for (int i = 0; i < LK_WALK_N; i++) {
    lkWalkIt = float(i + 1);
    vec2 g = g0 + dg * d;
    if (d > LK_DMAX || g.x < 0.0 || g.y < 0.0 || g.x >= Ng || g.y >= Ng) break;
    // The finest level the walk descends to grows with the distance (0.31 m to 12 m, 0.63 m to 30 m, 1.25 m beyond): far
    // faces need no finer place (their tops and colours come from bilinear samples), near ones do.
    int Lmin = d < 12.0 ? 0 : (d < 30.0 ? 1 : 2);
    L = max(L, Lmin);
    ivec2 gi = ivec2(g);
    ivec2 cl = gi >> L;
    float H = texelFetch(uLkHgt, cl, L).r;
    vec2 tb = (vec2((cl + st) << L) - g) * idg;
    float dExit = d + max(min(tb.x, tb.y), 0.0) + 0.003;
    if (y0 + m * d > H) {
      // Past the cell; climb only out of the parents it left (a parent still around the ray was split: its other children
      // are tested at this level, not re-split from above).
      ivec2 gN = ivec2(g0 + dg * dExit);
      d = dExit;
      for (int u = 0; u < 8; u++) {
        if (L >= top || (gN >> (L + 1)) == (gi >> (L + 1))) break;
        L++;
      }
      continue;
    }
    if (L > Lmin) {
      L--;
      continue;
    }
    // A texel whose top reaches the horizon ray: how high its surface rises seen from P.
    float tN = m;
    float cL = cell * exp2(float(L));
    for (int k = 0; k < 4; k++) {
      float dk = d + cL * (k == 0 ? 0.25 : (k == 1 ? 0.75 : (k == 2 ? 1.5 : 3.0)));
      tN = max(tN, (lkHgtAt(P.xz + hz0 * dk) - y0) / dk);
    }
    if (tN > m + 1e-6) {
      float eN = atan(tN);
      float FN = lkPhiT((eN - mu) / sigE);
      bool first = hits < 0.5;
      float share = first ? FN : FN - Fc;
      if (share > 0.002) {
        // The band's rays: their mean elevation, the face looked up there, box-filtered over the heights of the band (at most
        // +-1 sigma around the mean) and the azimuth spread at its distance.
        float eM = lkBandMean(eC, eN, mu, sigE, first ? pc : Fc, FN, first);
        float eLo = max(eC, eM - sigE);
        float eHi = min(eN, eM + sigE);
        float dF = d + 0.25 * cL;
        vec3 X = vec3(P.x + hz0.x * dF, 0.0, P.z + hz0.y * dF);
        vec2 uvM = lkProj(X + vec3(0.0, y0 + dF * tan(eM), 0.0));
        vec2 dyF = lkProj(X + vec3(0.0, y0 + dF * tan(eHi), 0.0)) - lkProj(X + vec3(0.0, y0 + dF * tan(eLo), 0.0));
        dyF += normalize(dyF + vec2(0.0, 1e-6)) * (0.5 / uEnvMirrorSize.y);
        vec2 dxF = K0 * (3.46 * sigA * dF / (t + dF)) + vec2(0.5 / uEnvMirrorSize.x, 0.0);
        vec3 cF = textureGrad(uEnvMirror, clamp(uvM, vec2(0.0005), vec2(0.9995)), dxF, dyF).rgb;
        // (Lab: with a short ?lkdmax the faces near its end fade over to the remainder's target march.)
        float w = 1.0 - smoothstep(0.9 * LK_DMAX, LK_DMAX, d);
        acc += share * w * cF;
        Fa += share * w;
        if (first) { lkDbgH = cF; dFirst = d; }
        hits += 1.0;
      }
      Fc = max(Fc, FN);
      m = tN;
      eC = eN;
      if (Fc > 0.995 || hits > 3.5) break;
    }
    // Past this texel (its box maximum may still stand above the raised ray).
    d = dExit;
  }
  lkHits = hits;
  lkWalkD = dFirst > 0.0 ? dFirst / (t + dFirst) : 1.0;
  lkWalkE = eC;
  return vec4(acc, Fa);
}
// The full lake reflection (v4): the walk term W (own or from the half-resolution pass), the lifted rays the walk did not
// account for (nothing rose above the horizon ray: they see the sky and clouds at the horizon), and the rays over every
// obstacle (as v3's remainder): two strata of equal share at their conditional quantiles, each a short parallax march
// box-filtered between its quantile bounds (the upper box ends at the 90 % quantile).
vec3 lkReflect4(vec2 uv0, vec2 gx, vec2 gy, float t, vec3 V, vec3 N, vec2 sig, vec2 extra, vec4 W, out float sHit) {
  uv0 += extra;
  vec4 c0 = uEnvMirrorViewProj * vec4(-V.x, V.y, -V.z, 0.0);
  vec2 p0 = c0.xy / max(c0.w, 1e-4);
  vec3 rc = reflect(-V, N);
  float mu = asin(clamp(rc.y, -1.0, 1.0));
  vec2 hz = normalize(rc.xz + vec2(1e-6, 0.0));
  float sigE = max(2.0 * 0.07 * sig.y, 1e-4);
  float sinA = clamp(V.y, 0.002, 0.99);
  float sigA = 2.0 * 0.07 * sig.x * sinA / sqrt(1.0 - sinA * sinA);
  float emin = asin(min(0.9 * sinA, 0.01));
  float pc = lkPhiT((emin - mu) / sigE);
  vec3 col = W.rgb;
  float Fc = max(W.a, pc);
  float pFree = max(pc - W.a, 0.0);
  lkDbgH = W.rgb / max(W.a, 1e-4);
  if (pFree > 1e-4) {
    // The lifted rays the walk saw meet nothing within LK_DMAX: what they reach beyond (the far shore, the icebergs, the sky)
    // from the target along the horizon ray, with one parallax step (the surface the target shows at the horizon's vanishing
    // point is reached at s = 1 - t / a of the way from the lake point's mirror point; no closer than LK_DMAX). (v4g took the
    // sky wherever the target showed a mesh there: the iceberg beyond 60 m went dark, WORK an/slab760.png.)
    vec3 dirH = vec3(hz.x * cos(emin), sin(emin), hz.y * cos(emin));
    vec4 c1 = uEnvMirrorViewProj * vec4(dirH, 0.0);
    vec2 duvE = (c1.xy / max(c1.w, 1e-4) - p0) * 0.5;
    vec4 cE = textureLod(uEnvMirror, clamp(uv0 + duvE, vec2(0.0005), vec2(0.9995)), 0.0);
    vec3 cFar = cE.rgb;
    if (cE.a < 59000.0) {
      float sE = clamp(1.0 - t / max(cE.a, 1e-3), LK_DMAX / (t + LK_DMAX), 1.0);
      vec4 cS = textureLod(uEnvMirror, clamp(uv0 + duvE * sE, vec2(0.0005), vec2(0.9995)), 0.0);
      cFar = cS.rgb;
    }
    col += pFree * cFar;
    if (W.a < 1e-4) lkDbgH = cFar;
    lkDbgE = vec4(uv0 + duvE, cE.a / 60000.0, dot(cE.rgb, vec3(0.2126, 0.7152, 0.0722)));
  }
  sHit = lkWalkD;
  lkDbgPc = Fc;
  lkDbgSH = lkWalkE;
  lkDbgU = vec3(0.0);
  if (Fc < 0.995) {
#if LK_STRATA == 3
    // Three strata of equal share (boxes between the conditional quantiles 0, 1/3, 2/3 and 0.975, each looked up at its
    // conditional median, 3 parallax steps): the sky brightens steeply with elevation toward the sun's side (sky_world.exr:
    // 0.04 at 0.5 deg, ~1 at 5 deg, ~2 at 12-20 deg), so the upper tail carries much of the pixel's light (2 strata ending at
    // the 90 % quantile left the near water 20-28 % under Cycles on the left, clouds off: WORK tools/bandcmp.py).
    float b0 = mu + sigE * lkPhiInv(Fc);
    float b1 = mu + sigE * lkPhiInv(Fc + (1.0 - Fc) / 3.0);
    float b2 = mu + sigE * lkPhiInv(Fc + (1.0 - Fc) * 2.0 / 3.0);
    float b3 = max(mu + sigE * lkPhiInv(Fc + (1.0 - Fc) * 0.975), b2 + 0.002);
    for (int k = 0; k < 3; k++) {
      float lo = k == 0 ? b0 : (k == 1 ? b1 : b2);
      float hi = k == 0 ? b1 : (k == 1 ? b2 : b3);
      float eq = clamp(mu + sigE * lkPhiInv(Fc + (1.0 - Fc) * (float(k) + 0.5) / 3.0), lo, hi);
      vec3 dR = vec3(hz.x * cos(eq), sin(eq), hz.y * cos(eq));
      lkDbgU += lkRay(uv0, p0, t, dR, max(hi - lo, 1e-4), sigA, gx, gy, 3);
    }
    lkDbgU *= 1.0 / 3.0;
#else
    float eLo = mu + sigE * lkPhiInv(Fc);
    float eMid = mu + sigE * lkPhiInv(Fc + 0.5 * (1.0 - Fc));
    float eHi = max(mu + sigE * lkPhiInv(Fc + 0.9 * (1.0 - Fc)), eMid + 0.002);
    for (int k = 0; k < 2; k++) {
      float lo = k == 0 ? eLo : eMid;
      float hi = k == 0 ? eMid : eHi;
      float eq = clamp(mu + sigE * lkPhiInv(Fc + (1.0 - Fc) * (k == 0 ? 0.25 : 0.7)), lo, hi);
      vec3 dR = vec3(hz.x * cos(eq), sin(eq), hz.y * cos(eq));
      lkDbgU += lkRay(uv0, p0, t, dR, max(hi - lo, 1e-4), sigA, gx, gy, 4);
    }
    lkDbgU *= 0.5;
#endif
    col += (1.0 - Fc) * lkDbgU;
  }
  return col;
}
#endif
`;

/**
 * Live lake surface. The Cycles plate already contains the calm water (mirror
 * reflections of sky and mountains, rendered without the Blender Wave modifier);
 * this shader animates it: concentric ripples under the hero, travelling impulse
 * rings on press/release, moving micro-ripples, the live reflection of the hero
 * and small sun glints.
 */

const WATER_VERT = /* glsl */ `
uniform mat4 uPlateViewProj;
uniform mat4 uMirrorViewProj;
varying vec4 vPlateClip;
varying vec4 vMirrorClip;
varying vec3 vWorldPos;
void main() {
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorldPos = wp.xyz;
  vPlateClip = uPlateViewProj * wp;
  vMirrorClip = uMirrorViewProj * wp;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`;

const WATER_FRAG = /* glsl */ `
${GLSL_COMMON}
${GLSL_ENV}
${GLSL_PLATE_OCCLUSION}
#ifdef EXTRA_PROJECTORS
${GLSL_EXTRA_PROJECTORS}
#endif
${GLSL_PLATE_GRADE}
${GLSL_PLATE_MIST}
uniform sampler2D uPlate;
uniform float uPlateGain;
uniform sampler2D uReflection;   // hero seen from the mirrored camera, premultiplied alpha
uniform float uReflectionOn;
uniform float uTime;
uniform float uFrame;
uniform vec3 uRippleCenter;
uniform float uRippleAmp;        // base ripple slope amplitude
uniform vec4 uImpulse;           // x: start time, y: amplitude, z: speed, w: width
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uDofBlur;
uniform float uFocusDist;
uniform float uDistortion;       // plate distortion strength (uv units per unit slope)
uniform float uMirror;           // reflectance used for the live hero reflection
uniform float uHold;             // dolly progress (0 at rest)
uniform float uFogHold;          // the hold fog bank (lingers after a release)
uniform float uRippleShade;
uniform vec3 uFog;               // x: start distance, y: full distance, z: amount
uniform vec3 uFogColor;
uniform vec3 uOrbCenter;
uniform float uOrbGlow;
varying vec4 vPlateClip;
varying vec4 vMirrorClip;
varying vec3 vWorldPos;
#ifdef BAKED_MIRROR
// Round 11 (baked environment): the lake is a true planar mirror. LakeMirror draws the environment (world sky, the raw
// baked meshes, the clouds; not BG.001, not the water) from the mirrored camera every frame: rgb = scene-linear radiance,
// a = mirror path length from the mirrored camera (60000 = sky). Sampled at vMirrorClip, as the hero reflection.
uniform sampler2D uEnvMirror;
uniform vec2 uEnvMirrorSize;      // texels
uniform mat4 uEnvMirrorViewProj;  // the target's view-projection (its own frustum, without the oblique clip)
uniform sampler2D uSkyEq;         // the world-only sky equirect (LakeMirror's sky pass)
uniform vec2 uMirrorP;            // the target projection's p00, p11
uniform vec2 uResolution;         // main HDR target size (px): the DOF in screen px
// The Cycles water's bump (Noise Texture scale 3 on object coordinates, i.e. 0.33 m features, detail 4; Bump distance 0.07,
// filter width 1): N' = normalize(N - 0.07 grad h). It does not blur the mirror, it breaks it into fine horizontal wavelets,
// each reflecting another patch of cloud or sky (Blender diagnostic, WORK/diag_lake: bump off the lake is a clean mirror of
// the massif, the iceberg, the clouds and the dark ridge; with it the clouds' light spreads over the whole lake and the
// mountains leave no reflection). A tilt delta moves the reflected ray's elevation by 2 delta, its azimuth only by
// 2 sin(grazing) delta. Cycles takes the slope over each pixel's footprint (ray differentials x filter width), so the finer
// octaves fade where the footprint along the view reaches their wavelength: wavelets near the camera, a calm mirror far out.
// The field is static, as the Cycles water (only its Wave modifier moves, the engine's ripple rings).
// x: tilt per unit slope of this noise (rad), y / z: an octave fades out between wavelength / footprint = y and z, w: gain
// of the fine octaves' spread.
uniform vec4 uLakeBump;
// Far-field spread (std, rad) reached between distances y and z (m): within a few degrees of grazing, the bump's tilts send
// many rays under the horizon into second bounces, and the Cycles lake washes the far shore's reflections out (WORK
// diag_lake: far-left 0.07 with the bump off, 0.34 with it); the octave model alone left the massif's foot reflected.
uniform vec3 uLakeFar;
// The reflection's level against the Cycles lake (fit at rest, readback vs WORK/diag_lake variant A: the live clouds and the
// model's spread leave the mirror ~12 % under the plate's lake).
uniform float uMirrorGain;
uniform float uLakeDebug;
#ifdef LAKE_CORR
// The static rest correction of the far water (pipeline/lake_corr_m9.py, A1 2.1 #12): a blurred ratio of the plate's lake to
// this mirror at rest, averaged over 4 clock times, on the rest plate's uv grid (log2 + 0.5). Indexed by the lake point's
// rest-camera projection, it is fixed on the water plane (no ghost when the camera moves). Far water only (near the rocks the
// two lakes disagree about near reflections, which move with the camera).
uniform sampler2D uLakeCorr;
#endif
vec3 lakeSky(vec3 d) {
  vec2 e = vec2(atan(d.z, d.x) * 0.15915494 + 0.5, asin(clamp(d.y, 0.0, 1.0)) * 0.31830989 + 0.5);
  return textureLod(uSkyEq, e, 0.0).rgb;
}
// The bump at a lake point, filtered by the along-view footprint fp (m): xy = the slope (d h / d x, d h / d z) per metre of
// the octaves coarser than the footprint (the pixel sees one tilt: a distortion), z = the RMS slope per axis of the finer
// ones (the pixel's samples spread over them: a blur). Each octave's slope RMS per axis is 1.5 x 0.764 (noised).
vec3 lakeBumpSlope(vec2 xz, float fp) {
  vec2 d = vec2(0.0);
  float v = 0.0;
  float b = 0.5;
  float f = 3.0;
  for (int i = 0; i < 4; i++) {
    float w = smoothstep(uLakeBump.z, uLakeBump.y, 1.0 / (f * fp));
    if (w > 0.0) d += b * f * w * noised(vec3(xz * f + float(i) * 17.31, float(i) * 3.7)).yz;
    v += 1.3133 * (1.0 - w * w);
    b *= 0.5;
    f *= 2.0;
  }
  return vec3(d, sqrt(v));
}
// The lake's reflection at a lake point P (step 2, third session; the 5 discrete elevation taps drew horizontal bands and the
// sub-pixel wavelets read as glitter that the Cycles lake, 64 jittered samples per pixel + OIDN, does not have): the ray
// reflected off the coarse tilt (the octaves the pixel resolves: wavelets near the camera), its elevation folded at the
// horizon (a ray tilted under it meets the water again and goes up), spread in elevation over the fine octaves as ONE
// anisotropic lookup: the footprint along the elevation's direction in the target is the screen footprint plus a box of
// 3.46 sig (the std of the spread), across it the screen footprint; both carry the lake's DOF (gx, gy: the target uv's
// screen derivatives x the DOF scale). Above the target's frustum (35 deg) the sky equirect by direction.
vec3 mirrorTex(vec2 uv0, vec2 gx, vec2 gy, float dist, vec3 V, vec3 P) {
  float sinA = clamp(V.y, 0.02, 0.99);
  vec3 r0 = vec3(-V.x, V.y, -V.z);
  vec4 c0 = uEnvMirrorViewProj * vec4(r0, 0.0);
  vec2 p0 = c0.xy / max(c0.w, 1e-4);
  vec3 s = lakeBumpSlope(P.xz, dist * 5.9e-4 / sinA) * uLakeBump.x;
  vec3 r = reflect(-V, normalize(vec3(-s.x, 1.0, -s.y)));
  float sig = 2.0 * s.z * uLakeBump.w;
  float sf = uLakeFar.x * smoothstep(uLakeFar.y, uLakeFar.z, dist);
  sig = sqrt(sig * sig + sf * sf);
  vec2 hz = normalize(r.xz + vec2(1e-6, 0.0));
  float e = max(abs(asin(clamp(r.y, -1.0, 1.0))), 0.0035);
  vec3 rc = vec3(hz.x * cos(e), sin(e), hz.y * cos(e));
  vec4 cc = uEnvMirrorViewProj * vec4(rc, 0.0);
  if (cc.w <= 1e-4) return lakeSky(rc);
  vec2 pc = cc.xy / cc.w;
  vec2 uv = uv0 + (pc - p0) * 0.5;
  if (uv.y < 0.0) return lakeSky(rc);
  // target uv per radian of elevation (the spread's direction and scale in the target)
  const float DE = 0.02;
  vec4 cu = uEnvMirrorViewProj * vec4(hz.x * cos(e + DE), sin(e + DE), hz.y * cos(e + DE), 0.0);
  vec2 J = (cu.xy / max(cu.w, 1e-4) - pc) * (0.5 / DE);
  float lj = max(length(J), 1e-6);
  vec2 dy = (J / lj) * (length(gy) + lj * 3.46 * sig);
  return textureGrad(uEnvMirror, clamp(uv, vec2(0.0005), vec2(0.9995)), gx, dy).rgb;
}
#ifdef LAKE_R12
${GLSL_LAKE_R12}
#endif
#endif

// Slope (dh/dx, dh/dz) of Blender's Wave modifier as used on the lake: a train of positive
// Gaussian crests leaving the centre (spacing 2.717 m, 1.115 m/s, 0.173 m after subdivision).
uniform vec4 uWave;   // x: amplitude, y: spacing, z: speed, w: crest sigma
uniform float uWaveReach;
vec2 ringSlope(vec2 d, float r) {
  // Broad rolling rings (a full sinusoid at the modifier's spacing and speed) under a smooth envelope: the
  // reference reads as a few wide waves with blue troughs, not thin contour lines (Gaussian crests did).
  // The ring phase wobbles a little with the angle: F000's wave fronts are scalloped, not drawn with a compass.
  float x = r - uWave.z * uTime + 0.09 * sin(atan(d.y, d.x) * 7.0 + r * 1.3) + 0.05 * sin(atan(d.y, d.x) * 13.0 - r * 0.9);
  float k = 6.2831853 / uWave.y;
  float dh = -uWave.x * k * 0.55 * sin(k * x);
  // (exp(-r / 4 m) with a 6-9 m cut-off left one or two soft bands; F000 shows three or four, QC round 5.)
  float env = smoothstep(0.4, 1.8, r) * exp(-r / (uWaveReach * 0.7)) * (1.0 - smoothstep(uWaveReach * 0.8, uWaveReach, r));
  return d / max(r, 1e-3) * dh * env;
}

vec2 impulseSlope(vec2 d, float r) {
  float t = uTime - uImpulse.x;
  if (t < 0.0 || t > 6.0) return vec2(0.0);
  float c = uImpulse.z * t;
  float x = (r - c) / uImpulse.w;
  // derivative of a gaussian ring, fading as it travels
  float g = -2.0 * x / uImpulse.w * exp(-x * x);
  float fade = exp(-t * 0.55) * smoothstep(0.0, 0.25, t);
  return d / max(r, 1e-3) * g * uImpulse.y * fade;
}

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

// The plate's lake is a mirror image baked for the plate camera. Sampled where a lake point projects, it
// paints those reflections onto the surface: as the camera moves (the hold dolly) the floes' long
// reflection streaks fan out across the lake like light shafts. Re-aim the lookup through the mirror image
// instead: what P reflects lies a distance L beyond P on the straight-through view ray (L traced at bake,
// uPlateDepth.b), and the plate shows that mirror point through the lake point on the line from the plate
// camera. Identity at the plate camera; one refinement with L read at the new point.
${mirrorLGLSL("Plate", "plate")}
vec3 plateMirrorPoint(vec3 P) {
  vec3 Cp = uPlateCamPos;
  vec3 dir = normalize(P - cameraPosition);
  vec3 Pp = P;
  for (int i = 0; i < 2; i++) {
    vec4 c = uPlateViewProjF * vec4(Pp, 1.0);
    vec2 uv = clamp(c.xy / c.w * 0.5 + 0.5, vec2(0.0), vec2(1.0));
    float L = min(plateMirrorL(uv), 4000.0);
    if (L <= 0.0) break;
    vec3 X = P + dir * L;
    Pp = Cp + (X - Cp) * ((Cp.y - P.y) / max(Cp.y - X.y, 1e-3));
  }
  return Pp;
}
${GLSL_EXTRA_MIRROR}

void main() {
#ifdef LK_WALKPASS
  {
    // The half-resolution walk pass (Water.renderWalk): the obstacle term only, from the same view, DOF footprint and bump
    // as the water's own pass below (nothing else of the water is needed for it).
    vec3 V0 = normalize(cameraPosition - vWorldPos);
    float dist0 = distance(cameraPosition, vWorldPos);
    float lodX0 = uDofBlur * smoothstep(0.0, mix(30.0, 10.0, uHold), abs(dist0 - uFocusDist)) + 1.6 * (1.0 - smoothstep(8.0 + 10.0 * uHold, 16.0 + 12.0 * uHold, dist0));
    float kDof0 = max(exp2(lodX0) * uResolution.x / 1800.0, 1.0);
    vec2 sg0;
    vec3 n0 = lkBump(vWorldPos, dFdx(vWorldPos), dFdy(vWorldPos), kDof0, sg0);
    gl_FragColor = lkWalkTerm(dist0, V0, n0, sg0, vWorldPos);
    return;
  }
#endif
  vec3 V = normalize(cameraPosition - vWorldPos);
  vec2 rel = vWorldPos.xz - uRippleCenter.xz;
  float r = length(rel);

  // The Wave modifier's crest train plus the press / release impulse: these shade the lake.
  vec2 waveS = ringSlope(rel, r) * uRippleAmp + impulseSlope(rel, r);
  // A light breeze (the Blender bump, noise scale 3): it only bends the reflections a little.
  vec4 m1 = fbmd(vec3(vWorldPos.x * 0.55, vWorldPos.z * 0.9, uTime * 0.12), 3);
  // Calmer inside the ring zone: the breeze grain masked the concentric bands (QC round 4: HF energy 2.37 vs 1.56).
  // (0.55 in the ring zone until QC round 10: the grain read through the rings.)
  vec2 slope = waveS + m1.yw * vec2(0.55, 0.9) * 0.006 * (0.3 + 0.7 * smoothstep(4.0, 12.0, r));

  // Distortion grows slightly with distance (reflections of far mountains bend more per slope).
  float dist = distance(cameraPosition, vWorldPos);
  vec2 offs = vec2(slope.x, -slope.y) * uDistortion * mix(0.6, 1.4, smoothstep(6.0, 60.0, dist));

#ifdef BAKED_MIRROR
  // Round 11 (baked environment): the planar mirror at this lake point, bent by the same ripple / breeze offsets. They were
  // tuned in plate uv (1.3 frame widths, 1.33 frame heights); the mirror image is the screen flipped left-right (the
  // mirrored camera's x axis is world -x). Nothing is hidden from a mirror: no fill, no re-aim, no plate coverage.
  vec4 mclip = uEnvMirrorViewProj * vec4(vWorldPos, 1.0);
  vec2 muv = mclip.xy / mclip.w * 0.5 + 0.5;
  // (In target uv: a frame width is tanH p00 of it, a frame height tanV p11; tanH 0.4263, tanV 0.2266 at the rest framing.)
  vec2 moffs = vec2(-offs.x * 1.3 * uMirrorP.x * 0.4263, offs.y * 1.33 * uMirrorP.y * 0.2266);
  // The lake's DOF as the plate's (QC round 8, T05): 2^lodX plate texels (1800 per frame width) = that many x W / 1800
  // screen px, applied to the target lookup's screen footprint (the specular point's uv, without the ripple offsets).
  float lodX = uDofBlur * smoothstep(0.0, mix(30.0, 10.0, uHold), abs(dist - uFocusDist)) + 1.6 * (1.0 - smoothstep(8.0 + 10.0 * uHold, 16.0 + 12.0 * uHold, dist));
  float kDof = max(exp2(lodX) * uResolution.x / 1800.0, 1.0);
#ifdef LAKE_R12
  // The Cycles bump (GLSL_LAKE_R12) and the planar mirror with parallax. The ring waves keep their image-space bend (the
  // breeze grain m1 emulated the Blender bump on the plate: the bump itself is exact here).
  vec2 offsW = vec2(waveS.x, -waveS.y) * uDistortion * mix(0.6, 1.4, smoothstep(6.0, 60.0, dist));
  vec2 moffsW = vec2(-offsW.x * 1.3 * uMirrorP.x * 0.4263, offsW.y * 1.33 * uMirrorP.y * 0.2266);
  vec2 lkSig;
  vec3 lkN = lkBump(vWorldPos, dFdx(vWorldPos), dFdy(vWorldPos), kDof, lkSig);
  float lkS;
#if defined(LK_V2)
  vec3 base = lkReflect(muv, dFdx(muv) * kDof, dFdy(muv) * kDof, dist, V, lkN, lkSig, moffsW, lkS) * uMirrorGain;
#elif defined(LK_HGT)
#ifdef LK_HALF
#ifdef LK_WALKREPROJ
  // The walk at this lake point's place in the walk's own frame: it may have been drawn a frame earlier or before a pure turn
  // of the camera (LakeSchedule); for the frame it was drawn in this is the pixel's own place.
  vec4 lkWc = uLkWalkVP * vec4(vWorldPos, 1.0);
  vec4 lkW = texture2D(uLkWalk, lkWc.xy / lkWc.w * 0.5 + 0.5);
#else
  vec4 lkW = texture2D(uLkWalk, gl_FragCoord.xy * uLkWalkInv);
#endif
#else
  vec4 lkW = lkWalkTerm(dist, V, lkN, lkSig, vWorldPos);
#endif
  // LK_GAIN: the level against the Cycles water at the same camera (rest, clouds at their Blender places: water band means
  // Cycles / engine 1.08-1.37 left and centre, 0.96-1.14 right, WORK tools/bandcmp.py; the flat mirrors agree within 10 %).
#ifdef LK_CACHEPASS
  // The cache pass (Water.renderCache): this term without the ring waves' bend, i.e. exactly what the water computes at every
  // pixel the waves do not reach (it depends on the camera, the DOF, the mirror and the walk target only, not on time). The
  // same call as the water's below (derivatives first, a run-time zero bend), so both compile to the same arithmetic.
  {
    vec2 lkGx0 = dFdx(muv) * kDof;
    vec2 lkGy0 = dFdy(muv) * kDof;
    // alpha = which lake plane wrote it (1 near, 2 far: 1.7 mm higher), so each plane's fragments read only their own values.
    gl_FragColor = vec4(lkReflect4(muv, lkGx0, lkGy0, dist, V, lkN, lkSig, uLkZero, lkW, lkS) * (uMirrorGain * LK_GAIN), vWorldPos.y > 0.00085 ? 2.0 : 1.0);
    return;
  }
#endif
#ifdef LK_CACHE
  // Frame budget (T1 at rest): while the camera stands still the term is read from the cache; pixels the ring waves or a
  // press / release impulse bend compute it (moffsW is exactly 0 elsewhere). ?lkcache=0: always computed.
  // (The screen derivatives are taken before the branch: derivatives inside non-uniform control flow are undefined.)
  vec2 lkGx = dFdx(muv) * kDof;
  vec2 lkGy = dFdy(muv) * kDof;
  // The cache pass is single-sampled: it writes where it covered the pixel centre, alpha = the lake plane (1 near, 2 far). MSAA
  // also shades edge pixels whose centre lies just outside a quad, and both planes meet along one row (z -14.87 m): a
  // fragment reads the cache only where its own plane wrote it, else it computes the term.
  vec4 lkC = vec4(0.0);
  if (uLkCacheOn > 0.5 && moffsW.x == 0.0 && moffsW.y == 0.0) lkC = texelFetch(uLkCache, ivec2(gl_FragCoord.xy), 0);
  vec3 base;
  lkS = 0.0;
  if (abs(lkC.a - (vWorldPos.y > 0.00085 ? 2.0 : 1.0)) < 0.5) base = lkC.rgb;
  else base = lkReflect4(muv, lkGx, lkGy, dist, V, lkN, lkSig, moffsW, lkW, lkS) * (uMirrorGain * LK_GAIN);
#else
  vec3 base = lkReflect4(muv, dFdx(muv) * kDof, dFdy(muv) * kDof, dist, V, lkN, lkSig, moffsW, lkW, lkS) * (uMirrorGain * LK_GAIN);
#endif
  if (uLakeDebug > 10.5) {
    gl_FragColor = lkDbgE;
    return;
  }
  if (uLakeDebug > 9.5) {
    // Calibration (lab): the heightfield walk's iterations, the first obstacle's parallax fraction, the obstacles met.
    gl_FragColor = vec4(lkWalkIt, lkS, lkHits, 1.0);
    return;
  }
#else
  vec3 base = lkReflect3(muv, dFdx(muv) * kDof, dFdy(muv) * kDof, dist, V, lkN, lkSig, moffsW, vWorldPos, lkS) * uMirrorGain;
#endif
  if (uLakeDebug > 8.5) {
    // Calibration (lab): the remainder (the rays over the first obstacle), scene-linear.
    gl_FragColor = vec4(lkDbgU * uMirrorGain, 1.0);
    return;
  }
  if (uLakeDebug > 7.5) {
    gl_FragColor = vec4(lkDbgPc, lkDbgSH, lkS, 1.0);
    return;
  }
  if (uLakeDebug > 6.5) {
    gl_FragColor = vec4(lkDbgH * uMirrorGain, 1.0);
    return;
  }
  if (uLakeDebug > 5.5) {
    // Calibration (lab): the flat mirror (no bump): LakeMirror's target at the lake point's own mirror point, the path
    // length beyond the lake point in alpha.
    vec4 fm = textureLod(uEnvMirror, muv, 0.0);
    gl_FragColor = vec4(fm.rgb * uMirrorGain, fm.a - dist);
    return;
  }
  if (uLakeDebug > 4.5) {
    // Calibration (lab): the noise itself (check against Blender's values): fBm of all octaves, octave 0, octave 4.
    vec3 pb = vec3(vWorldPos.x, -vWorldPos.z, vWorldPos.y);
    bool fp = pb.y > 11.920909;
    vec3 co = fp ? vec3(pb.x, pb.y - 34.2286, 0.10754) : vec3(pb.x, pb.y, 0.0);
    float s = 0.0, a = 1.0, f = 3.0;
    for (int i = 0; i < 5; i++) {
      s += a * 0.982 * lkPerlin(co * f, fp);
      a *= 0.5;
      f *= 2.0;
    }
    gl_FragColor = vec4(0.5 * s / 1.9375 + 0.5, lkPerlin(co * 3.0, fp), lkPerlin(co * 48.0, fp), 1.0);
    return;
  }
  if (uLakeDebug > 2.5) {
    // Calibration (lab): the lake point (registration check against the Cycles cameras).
    gl_FragColor = vec4(vWorldPos.x, -vWorldPos.z, uLakeDebug > 3.5 ? lkSig.x : lkSig.y, 1.0);
    return;
  }
  if (uLakeDebug > 1.5) {
    // Calibration (lab): r = the coherent elevation offset of the reflected ray (deg), g = the incoherent elevation spread
    // (deg), b = the parallax search's lookup fraction.
    float de = degrees(asin(clamp(reflect(-V, lkN).y, -1.0, 1.0)) - asin(clamp(V.y, -1.0, 1.0)));
    gl_FragColor = vec4(de, degrees(2.0 * 0.07 * lkSig.y), lkS, 1.0);
    return;
  }
#else
  vec3 base = mirrorTex(muv + moffs, dFdx(muv) * kDof, dFdy(muv) * kDof, dist, V, vWorldPos) * uMirrorGain;
#ifdef LAKE_CORR
  base *= exp2(texture2D(uLakeCorr, clamp(vPlateClip.xy / vPlateClip.w * 0.5 + 0.5, vec2(0.0), vec2(1.0))).rgb - 0.5);
#endif
#endif
  // Calibration (lab): the raw reflection, scene-linear, as the Cycles plate's lake (read back from the HDR target).
  if (uLakeDebug > 0.5) {
    gl_FragColor = vec4(base, 1.0);
    return;
  }
  float occl = 0.0;
#else
  // Plate reflections re-aimed for this camera (see plateMirrorPoint); lake hidden from the projector
  // (behind a rock or a floe) takes the open water beside it.
  vec4 pclip = vPlateClip;
  vec3 pw = vWorldPos;
  float occl = 0.0;
  float vis0 = 1.0;   // the rest projector sees the point its lookup shows (extra-projector blend weight)
  float camAway = distance(cameraPosition, uPlateCamPos);
  if (uPlateDepthOn > 0.5 && camAway > 0.02) {
    pw = plateMirrorPoint(vWorldPos);
    pclip = uPlateViewProjF * vec4(pw, 1.0);
    vec2 ruv = pclip.xy / pclip.w * 0.5 + 0.5;
    float behind = -(uPlateView * vec4(pw, 1.0)).z - (plateDepthAt(clamp(ruv, vec2(0.0), vec2(1.0))) * 1.06 + 0.8);
    vis0 = 1.0 - smoothstep(0.0, 2.5, behind);
    // Far from the plate camera (the hold dolly, ~8 m) the lake hidden from the projector behind the near
    // floes and rocks is large, and the sideways fill smears it into stair-stepped streak bands (QC round 2,
    // p04-p06 bottom corners): there the live mirror takes over. Soft-edged: lake just behind an occluder's
    // shadow line blends over a couple of metres.
    occl = smoothstep(0.0, 2.5, behind) * smoothstep(1.0, 4.0, camAway);
    // A re-aimed lookup whose mirror point the projector could not see (behind a floe or a rock) took its
    // texels from the side, row by row: striped, floe-shaped bands and dark slabs on the near lake whenever the
    // pointer orbited the camera (pointer QC, right edge). Where the projector does see this lake point itself,
    // the straight lookup is clean, and an orbit of a metre or two barely moves the reflections it shows. (Lake
    // hidden both ways, the slivers between the foreground rocks, keeps the re-aimed fill: the straight fill
    // there drew vivid blue squiggles along the rock edges.)
    if (behind > 0.0) {
      vec2 suv = vPlateClip.xy / vPlateClip.w * 0.5 + 0.5;
      float sBehind = -(uPlateView * vec4(vWorldPos, 1.0)).z - (plateDepthAt(clamp(suv, vec2(0.0), vec2(1.0))) * 1.06 + 0.8);
      if (sBehind <= 0.0) {
        pw = vWorldPos;
        pclip = vPlateClip;
        vis0 = 1.0;
      }
    }
  }
  // The lake never takes a floe's or a rock's texel: where the surface the projector saw at the lookup stands above
  // the water (rebuilt along the projector ray), this lake point is hidden behind it, however close the depths. The
  // x1.06 + 0.8 m tolerance let the lake just behind the near floe slab show the slab's top as a second, translucent
  // layer when the pointer raised the camera (QC round 5). Such a point takes the fill (lake on the same row, so at
  // the same distance) sampled blurred (its per-row source jumps drew stripes), and gives way to an extra projector
  // that sees it. Near field only: the far lake's depth texels are too coarse for a 0.1 m test.
  float raised = 0.0;
  if (uPlateDepthOn > 0.5 && camAway > 0.02) {
    vec2 ruv = clamp(pclip.xy / pclip.w * 0.5 + 0.5, vec2(0.0), vec2(1.0));
    float dz = plateDepthAt(ruv);
    float fzw = -(uPlateView * vec4(pw, 1.0)).z;
    vec3 seen = uPlateCamPos + (pw - uPlateCamPos) * (dz / max(fzw, 1e-3));
    raised = smoothstep(0.05, 0.12, seen.y - pw.y) * (1.0 - smoothstep(40.0, 60.0, fzw));
  }
  vec2 puv0 = pclip.xy / pclip.w * 0.5 + 0.5;
  vec2 puv = plateUnoccluded(puv0, pw, step(0.5, raised));
  // No plausible fill source (it would have copied the rock or floe in front): the live mirror takes the lake there.
  float nofill = step(puv.x, -0.5);
  if (nofill > 0.5) puv = puv0;
  vis0 *= 1.0 - raised;
  // The +5 mips belong to the rest projector's fill only: the extra projectors see their lake points cleanly (lodX).
  // Shared, it turned every extra-projector sample behind a near floe or rock into a pale smooth slab outlined by the
  // rest projector's stair-stepped mask (QC round 6, release / cursor orbit).
  // Hold DOF as the plate (QC round 8, T05).
  float lodX = uDofBlur * smoothstep(0.0, mix(30.0, 10.0, uHold), abs(dist - uFocusDist)) + 1.6 * (1.0 - smoothstep(8.0 + 10.0 * uHold, 16.0 + 12.0 * uHold, dist));
  // (+5 until QC round 8, T02: a 5-mip average of rock, snow and water drew a boxy pale halo the shape of the depth texel
  // around small rocks at the in-between pop / release cameras; +3 still hides the fill's per-row jumps.)
  float lod = lodX + 3.0 * raised;
  vec2 quv = clamp(puv + offs, vec2(0.0005), vec2(0.9995));
  // The ripple-bent lookup must still land on the lake: beside a rock or a floe it fetched the rock itself and drew
  // a translucent copy of it on the water (QC round 4, idle sweep: a doubled snow-capped rock at the frame bottom).
  // (A depth-ratio rule alone let a lake point just behind a near rock or floe, 13.5 m vs 14 m, fetch the rock: a dark,
  // rippling copy of its edge 5-6 px out on the water, QC rounds 7-8. The surface seen at the lookup must be the water.)
  if (uPlateDepthOn > 0.5) {
    vec2 cuv = clamp(puv, vec2(0.0005), vec2(0.9995));
    quv = mix(quv, cuv, max(step(0.05, plateSeenY(quv) - vWorldPos.y), step(plateDepthAt(quv), plateDepthAt(cuv) * 0.92 - 0.3)));
  }
  vec3 base = textureLod(uPlate, quv, lod).rgb;
  // The plate's mid and far water carries fine horizontal streak grain (QC round 1: vertical |dL| 10 vs
  // a glassy reference): a small vertical Gaussian there keeps the vertical reflection columns.
#ifdef WATER_GLITTER
  float destreak = smoothstep(12.0, 35.0, dist);
#else
  float destreak = 0.0;   // T0: four extra plate fetches over most of the lake are not worth it
#endif
  if (destreak > 0.0) {
    float ty = 1.5 / float(textureSize(uPlate, 0).y);
    vec3 blur = base * 0.4026
      + (textureLod(uPlate, quv + vec2(0.0, ty), lod).rgb + textureLod(uPlate, quv - vec2(0.0, ty), lod).rgb) * 0.2442
      + (textureLod(uPlate, quv + vec2(0.0, 2.0 * ty), lod).rgb + textureLod(uPlate, quv - vec2(0.0, 2.0 * ty), lod).rgb) * 0.0545;
    base = mix(base, blur, destreak);
  }
#ifdef EXTRA_PROJECTORS
  // Extra projectors (hold pose, orbit extremes): their lakes show the near water, the floes and their reflections
  // as Cycles rendered them from (nearly) this camera, where the rest plate tore into stair-stepped bands or had to
  // fill from the side. Same re-aim and occlusion logic; weighted by proximity and by who sees the mirror point.
  float extraCover = 0.0;
  {
    vec2 e0 = min(puv, 1.0 - puv);
    float w0 = max(uRestMix, 0.001) * (vis0 + 0.02) * smoothstep(-0.005, 0.035, min(e0.x, e0.y)) * step(0.0, pclip.w);
    vec3 acc = base * w0;
    float wsum = w0;
${GLSL_WATER_PROJECTOR_BLEND}
    if (wsum > 1e-4) base = acc / wsum;
  }
#endif
#endif
#ifdef BAKED_MIRROR
  base = envChroma(base);
#else
  base = envChroma(base * uPlateGain);
#endif
  // The open lake reads a little brighter than this plate in the reference (F000 near water +7 %); the
  // shadow grade of the proxies is not applied here (it darkened the lake further).
  base *= 1.1;
  {
    // Near crushed blacks on the water, as the plate's near lift (QC round 9, cursor-orbit CRITICAL: with the pointer low,
    // the rocks' dark reflections at the frame bottom stayed near-black, L7-20, under rocks lifted to L28: a hard black
    // band at the waterline with a stair-stepped end). L20 -> 34.
    float nearKw = 1.0 - smoothstep(12.0, 22.0, dist);
    float lnw = dot(base, LUMA);
    float shKw = nearKw * (1.0 - smoothstep(0.02, 0.12, lnw));
    base = mix(base, mix(vec3(lnw), base, 0.7) * 1.25 + vec3(0.006, 0.008, 0.01), shKw * 0.8);
  }
  {
    // The same crushed-black toe as the plate (QC rounds 9-10: a pure-black slit under the right floe's overhang, p0.1 4.6).
    float lzw = dot(base, LUMA);
    if (lzw < 0.045) {
      float lzwt = 0.045 * pow(max(lzw, 0.0) / 0.045, 0.7);
      base = mix(vec3(lzwt), base * (lzwt / max(lzw, 1e-5)), 0.75);
    }
  }
#ifdef BAKED_MIRROR
  float plateW = 1.0;
#else
  // The plate's reflections are baked for the rest camera; outside it (and as the camera dollies
  // in, when they would smear along the surface) the lake becomes a live mirror of the panorama.
  vec2 edge = min(puv, 1.0 - puv);
  float inside = smoothstep(-0.005, 0.035, min(edge.x, edge.y)) * step(0.0, pclip.w);
  // Dollied in, the plate keeps most of the lake: its reflections are re-aimed for the moving camera now
  // (plateMirrorPoint), so only a little live mirror is mixed in.
  float plateW = inside * (1.0 - 0.15 * smoothstep(0.05, 0.6, uHold));
  // Where the dolly magnifies the plate past ~2x (the near water at the frame's bottom corners), its texels
  // show as stair-stepped streaks: fade those to the live rippled mirror (QC round 2, p04-p06).
  vec2 tpp = fwidth(puv) * vec2(textureSize(uPlate, 0));
  float texPerPx = max(tpp.x, tpp.y);
  plateW *= mix(1.0, smoothstep(0.3, 0.6, texPerPx), smoothstep(0.02, 0.3, uHold));
  plateW *= 1.0 - occl;
  plateW *= 1.0 - nofill;
  // Dollied in, the near lake (< ~20 m) leaves what the plate can show without tearing: it becomes the live
  // rippled mirror (QC round 2: comb / stair-step texel stripes in p04-p06's foreground water).
  plateW *= 1.0 - smoothstep(0.1, 0.7, uHold) * (1.0 - smoothstep(14.0, 22.0, dist));
#ifdef EXTRA_PROJECTORS
  // Where an extra projector covers the lake, its texels are good from this camera: no fallback to the live mirror.
  plateW = max(plateW, extraCover);
#endif
#endif
  vec3 Nw = normalize(vec3(-waveS.x, 1.0, -waveS.y));
  // A soft lookup: at 0.05 every crest mirrored the panorama's clouds and ridges as thin contour lines; the
  // reference's rings are broad rolling bands.
  vec3 rRip = min(envRadiance(reflect(-V, Nw), 0.2), vec3(6.0));
  if (plateW < 1.0) {
    // Seen from low and close, regular crests mirror the panorama as hard stripes; the reference
    // (F420) shows soft, irregular waves there: weaker crests, broken up by the breeze.
    vec2 sl = waveS * 0.25 + m1.yw * vec2(0.55, 0.9) * 0.035;
    vec3 Nl = normalize(vec3(-sl.x, 1.0, -sl.y));
    vec3 rLive = min(envRadiance(reflect(-V, Nl), 0.16), vec3(6.0));
    // Water, not snow: the reference lake (F420) is a mid blue-grey under the dolly, not a white sheet.
    vec3 live = rLive * vec3(0.62, 0.7, 0.8);
    // Where the projector could not see the lake the mirror stands alone: a little darker, to sit with the
    // plate water around it (a blurred plate around the fill came out blocky, the fill jumps per row).
    live *= 1.0 - 0.12 * occl;
    base = mix(live, base, plateW);
  }
  // Crest bands (F082): a tilted facet reflects higher, bluer sky (dark band) or the pale horizon
  // (light band). Applied as a clamped brightness ratio so the plate keeps its own colours.
  vec3 rFlat = min(envRadiance(reflect(-V, vec3(0.0, 1.0, 0.0)), 0.2), vec3(6.0));
  // Symmetric, so the bands average out to the calm plate's brightness (as in F000).
  // The reference's concentric ring is strong: troughs #8da2c3 against crests #c8d1e0 (F000).
  // (x1.35 and +-0.55 since QC round 5: the reference's troughs are crisp, saturated blue bands.)
  // (x1.35 / +-0.55 in round 6 read as smooth, over-dark painted stripes in round 7: x1.0 / +-0.4, water L170 vs F000 170.)
  // (+-0.48 since QC round 10: "faint and grainy" vs F000's bold troughs; between round 7's +-0.55 stripes and +-0.4.)
  float k = clamp((dot(rRip, LUMA) - dot(rFlat, LUMA)) / max(dot(rFlat, LUMA), 1e-3) * uRippleShade, -0.48, 0.48);
  k *= plateW;
  base *= 1.0 + k;
  // Troughs mirror the bluer sky higher up (QC round 4: trough B-R 42 vs the reference's 56).
  base = mix(base, base * vec3(0.6, 0.77, 1.16), clamp(-k * 1.4, 0.0, 0.55));
  // Distance haze (the reference has more aerial perspective than the plate).
  float fogD = smoothstep(uFog.x, uFog.y, dist);
  base = mix(base, uFogColor, fogD * uFog.z);
  // The hold fog bank runs on over the far lake (the plate's field, so the shore line does not show).
  {
    // Two-tone with the bank's billow, cap 0.8 (QC round 8, T05; as the plate).
    float bk = plateBank(dist, vWorldPos, uFogHold, uTime);
    vec3 bankC = mix(uFogColor * vec3(0.30, 0.37, 0.46), uFogColor * vec3(0.44, 0.54, 0.66), plateBankBillow);
    base = mix(base, bankC * 1.08, min(bk, 0.88));
  }
  // The far-shore mist band continues across the water (same wisps, colour and strength as the plate's since QC round 10).
  base = mix(base, MIST_COLOR * vec3(0.81, 0.9, 1.0), min(plateMist(dist, 0.0) * plateMistWisp(vWorldPos, uTime) * 0.7, 0.85));

  // Live hero reflection (rendered from the mirrored camera). The reference lake is choppy where the
  // sculpture's image falls (F000), so it never reads as a clean arc: small moving facets break it into
  // glints and soft fragments.
  vec3 col = base;
  if (uReflectionOn > 0.5) {
    vec2 ruv = vMirrorClip.xy / vMirrorClip.w * 0.5 + 0.5;
#ifdef LAKE_R12
    // The hero's reflection through the same Cycles bump (no invented chop): the tilted ray's direction offset in the hero
    // mirror target (the camera's own frustum), scaled by the hero's parallax factor D / (t + D) (D: lake point to the orb),
    // plus the ring waves' bend.
    vec3 rT = reflect(-V, lkN);
    rT.y = max(rT.y, min(0.9 * V.y, 0.01));
    vec4 hc0 = uMirrorViewProj * vec4(-V.x, V.y, -V.z, 0.0);
    vec4 hc1 = uMirrorViewProj * vec4(rT, 0.0);
    float Dh = distance(vWorldPos, uOrbCenter);
    vec2 rOffs = (hc1.xy / max(hc1.w, 1e-4) - hc0.xy / max(hc0.w, 1e-4)) * 0.5 * (Dh / (dist + Dh)) + offsW * 1.6;
    vec4 refl = texture2D(uReflection, ruv + rOffs);
    float glint = 1.0;
#else
    // Broad, gentle chop (finer painted the horizon with streaks), fading out beyond 25-35 m (0.009 until QC round 7: the
    // near reflection stayed a smooth smear).
    vec4 chop = fbmd(vec3(vWorldPos.x * 1.3, vWorldPos.z * 2.0, uTime * 0.45), 2);
    float chopK = 1.0 - smoothstep(25.0, 35.0, dist);
    vec2 rOffs = offs * 1.6 + vec2(chop.y, -chop.w) * 0.014 * chopK;
    vec4 refl = texture2D(uReflection, ruv + rOffs);
    float glint = mix(1.0, smoothstep(0.1, 0.75, chop.x * 0.5 + 0.5), chopK);
#endif
    // Fresnel-weighted (a flat 0.3-0.6 mirrored the hero as strongly at the frame bottom, ~13 deg to the water, as mid-lake)
    // and hidden where the plate already reflects something nearer than the hero along this mirror ray (a rock or floe
    // a few metres off: the hero's image belongs behind it). QC round 7, T01.
    float Fw = 0.02 + 0.98 * pow(1.0 - saturate(dot(V, Nw)), 5.0);
    float w = uMirror * Fw * mix(0.55, 1.0, glint) * mix(1.0, 0.75, uHold);
#ifdef BAKED_MIRROR
    // The mirror path beyond the lake point to what the mirror shows there (the target's alpha is the whole path from the
    // mirrored camera; 60000 = sky).
    float Lb = textureLod(uEnvMirror, clamp(muv, vec2(0.0), vec2(1.0)), 0.0).a - dist;
#else
    float Lb = textureLod(uPlateDepth, clamp(puv, vec2(0.0), vec2(1.0)), 0.0).b;
#endif
    float Lh = distance(vWorldPos, uOrbCenter);
    w *= Lb <= 0.0 ? 1.0 : smoothstep(0.55, 0.8, Lb / max(Lh, 1e-3));
    col = col * (1.0 - refl.a * w) + refl.rgb * w;
  }
  // The orb is a light: its reflection on the rippled water under the sculpture is a band of glitter on the
  // crest faces (F000: x 700-800, y 660-720, ~186,203,222), not a soft glow. Every tier; the small facets
  // only exist in the ripple zone (elsewhere the speckle read as grain on glassy water).
  vec3 lO = normalize(uOrbCenter - vWorldPos);
  float zone = 1.0 - smoothstep(uWaveReach * 0.5, uWaveReach * 0.95, r);
  if (zone > 0.0) {
#ifdef WATER_GLITTER
    vec4 sp = fbmd(vec3(vWorldPos.x * 9.0, vWorldPos.z * 14.0, uTime * 1.3), 2);
    vec3 Ns = normalize(vec3(-waveS.x, 1.0, -waveS.y) + vec3(sp.y, 0.0, sp.w) * 0.12);
    float spark = smoothstep(0.35, 0.85, sp.x * 0.5 + 0.5);
#else
    // T0: the streak from the ripple normal alone (no facet noise).
    vec3 Ns = Nw;
    float spark = 0.6;
#endif
    // A soft cyan-white sheen with a little glitter in it (pinpoint sparkle alone read as sun glitter).
    col += vec3(0.7, 0.88, 1.0) * uOrbGlow * 0.5 * ggxSpec(Ns, V, lO, 0.28) * (0.6 + 0.4 * spark) * zone;
  }

#ifdef BAKED_EDGE
  // Round 11 fix round (baked environment): the view distance in alpha for EnvEdge (floe and rock silhouettes on the water).
  gl_FragColor = vec4(col, dist);
#else
  gl_FragColor = vec4(col, 1.0);
#endif
}
`;

function quad(min: THREE.Vector3Tuple, max: THREE.Vector3Tuple, y: number, segments: number) {
  const w = max[0] - min[0];
  const d = max[2] - min[2];
  const geo = new THREE.PlaneGeometry(w, d, segments, segments);
  geo.rotateX(-Math.PI / 2);
  geo.translate((min[0] + max[0]) / 2, y, (min[2] + max[2]) / 2);
  return geo;
}

export class Water {
  readonly group = new THREE.Group();
  readonly material: THREE.ShaderMaterial;
  readonly mirrorViewProj = new THREE.Matrix4();

  constructor(
    plate: THREE.Texture,
    plateViewProj: THREE.Matrix4,
    plateGain: number,
    shared: SharedUniforms,
    envDefines: Record<string, string>,
    occlusion: PlateOcclusionUniforms,
    opts: {
      glitter?: boolean;
      projectors?: ExtraProjectorBinding;
      /**
       * Round 11 (baked environment): the planar mirror replaces the plate: LakeMirror's target, its size in texels and its
       * per-frame lookup uniforms (uSkyEq, uEnvMirrorViewProj, uMirrorP; the sky pass's uMirrorInvViewProj, uMirrorCamPos).
       */
      mirror?: {
        texture: THREE.Texture;
        size: THREE.Vector2;
        uniforms: Record<string, { value: unknown }>;
        /** The static rest correction of the far water (assets lakeCorr), or null. */
        corr?: THREE.Texture | null;
        /**
         * Round 11 user-priority round (WATER lane): the Cycles water reproduced (GLSL_LAKE_R12): exact bump, parallax lookup.
         * False = the ENV lane's mirror model (`?envlake=mirror`).
         */
        r12?: boolean;
        /** Lake v4: the static max-mip heightfield of the baked meshes (LakeHeight), or null (v3's target march). */
        height?: { texture: THREE.Texture; grid: THREE.Vector4; top: number } | null;
      };
    } = {},
  ) {
    const defines: Record<string, string> = { ...envDefines, ...(opts.projectors?.defines ?? {}) };
    if (opts.glitter !== false) defines.WATER_GLITTER = "";
    const mirrorUniforms: Record<string, { value: unknown }> = {};
    let walkHalf = false;
    let lkCache = false;
    if (opts.mirror) {
      defines.BAKED_MIRROR = "";
      Object.assign(mirrorUniforms, opts.mirror.uniforms);
      mirrorUniforms.uEnvMirror = { value: opts.mirror.texture };
      mirrorUniforms.uEnvMirrorSize = { value: opts.mirror.size };
      // Fit at rest against the Cycles lake (WORK/LOG.md 2026-11-14 22:20-23:00: Blender diagnostic + readback + display
      // sweeps): weak near-field wavelets, the fine octaves' spread washing the far mountains' reflections out.
      mirrorUniforms.uLakeBump = { value: new THREE.Vector4(0.008, 2.0, 0.7, 1.4) };
      mirrorUniforms.uMirrorGain = { value: 1.03 };
      mirrorUniforms.uLakeFar = { value: new THREE.Vector3(0.05, 15, 45) };
      mirrorUniforms.uLakeDebug = { value: 0 };
      mirrorUniforms.uResolution = shared.uResolution;
      if (opts.mirror.r12) {
        defines.LAKE_R12 = "";
        // (Lab: `?lkv=2` = the earlier strata model, for A/B.)
        const lq = typeof location !== "undefined" ? new URLSearchParams(location.search) : null;
        const lkv = lq?.get("lkv") ?? null;
        if (lkv === "2") defines.LK_V2 = "";
        // v4 (default): the first obstacle from the heightfield; `?lkv=3` keeps v3's target march.
        else if (opts.mirror.height && lkv !== "3") {
          defines.LK_HGT = "";
          // The walk runs at 1/16 of the pixels (walkDiv 4): it can follow the lifted rays across the whole grid (the floes,
          // the shore, the ridge and massif bases, the icebergs out to 300 m). From the mirror camera, 2-3 m under the water,
          // the horizon direction shows only sky up to ~300 m (its line of sight stays under the water plane that long), so
          // no target lookup can stand in for these hits (v4h, 60 m: the near-left water 20-28 % under Cycles).
          defines.LK_WALK_N = String(Math.round(Number(lq?.get("lkwalk"))) || 160);
          defines.LK_DMAX = (Number(lq?.get("lkdmax")) || 320).toFixed(1);
          defines.LK_HAZ = lq?.get("lkhaz") === "0" ? "0" : "1";
          defines.LK_STRATA = lq?.get("lkstrata") === "2" ? "2" : "3";
          defines.LK_GAIN = (Number(lq?.get("lkgain")) || 1.12).toFixed(3);
          mirrorUniforms.uLkHgt = { value: opts.mirror.height.texture };
          mirrorUniforms.uLkHgtG = { value: opts.mirror.height.grid };
          mirrorUniforms.uLkHgtTop = { value: opts.mirror.height.top };
          // The walk term at half resolution, redrawn only when the camera moved (renderWalk); `?lkhalf=0` = per pixel.
          if (lq?.get("lkhalf") !== "0") {
            walkHalf = true;
            defines.LK_HALF = "";
            mirrorUniforms.uLkWalk = { value: null };
            mirrorUniforms.uLkWalkInv = { value: new THREE.Vector2(1, 1) };
            // Frame budget (LakeSchedule, default; `?lkperf=0` = lake v4 before it, exactly): the water reads the walk at the
            // lake point's place in the walk's own frame (so the walk may be drawn on another frame than the mirror, and a
            // turning camera needs no new walk), and the reflection term is cached while the camera stands still
            // (renderCache; lab `?lkcache=0`: computed every frame).
            if (lq?.get("lkperf") !== "0") {
              this.scheduled = true;
              defines.LK_WALKREPROJ = "";
              mirrorUniforms.uLkWalkVP = { value: new THREE.Matrix4() };
              if (lq?.get("lkcache") !== "0") {
                lkCache = true;
                defines.LK_CACHE = "";
                mirrorUniforms.uLkCache = { value: null };
                mirrorUniforms.uLkCacheOn = { value: 0 };
                mirrorUniforms.uLkZero = { value: new THREE.Vector2(0, 0) };
              }
            }
          }
        }
        // (No far-water rest correction: it was a fit of the ENV lane's model to the plate.)
      } else if (opts.mirror.corr) {
        defines.LAKE_CORR = "";
        mirrorUniforms.uLakeCorr = { value: opts.mirror.corr };
      }
    }
    this.material = new THREE.ShaderMaterial({
      name: "rx-water",
      vertexShader: WATER_VERT,
      fragmentShader: WATER_FRAG,
      defines,
      uniforms: {
        ...(opts.projectors?.uniforms ?? {}),
        uEnvMap: shared.uEnvMap,
        uEnvIntensity: shared.uEnvIntensity,
        uPlate: { value: plate },
        uPlateGain: { value: plateGain },
        // Crest sigma widened from the modifier's 0.42 m: the subdivided Cycles surface is smoother,
        // and the reference reads as a few broad soft bands (F000 / F082), not thin lines.
        // Spacing 4.2 m (the modifier's 2.717 read as fine grey rings; QC round 2 wants 2-3 broad bands).
        // The height scales with it (0.173 x 4.2 / 2.717) so the crest slopes, i.e. the shading, keep their strength.
        uWave: { value: new THREE.Vector4(0.26, 4.2, 1.115, 1.1) },
        // The Blender front keeps growing; 15 m keeps the bands gathered under the hero (F000-F082).
        // A few strong crests gathered under the hero, glassy water beyond (F000).
        // (11 since QC round 5's "3-4 bands"; 8 since round 7: the field ran across the whole frame, F000's is compact.)
        uWaveReach: { value: 8 },
        uPlateViewProj: { value: plateViewProj },
        uMirrorViewProj: { value: this.mirrorViewProj },
        uReflection: { value: null },
        uReflectionOn: { value: 0 },
        uTime: shared.uTime,
        uFrame: shared.uFrame,
        uRippleCenter: { value: new THREE.Vector3().fromArray(WATER.rippleCenter) },
        // 1 = the Blender crests (0.173 m after subdivision, slopes up to ~0.35).
        uRippleAmp: { value: 1.0 },
        uImpulse: { value: new THREE.Vector4(-100, 0, 3.2, 0.9) },
        uSunDir: shared.uSunDir,
        uSunColor: shared.uSunColor,
        uDofBlur: shared.uDofBlur,
        uFocusDist: shared.uFocusDist,
        uDistortion: { value: 0.035 },
        uMirror: { value: 1.0 },
        uHold: shared.uHold,
        uFogHold: shared.uFogHold,
        // (2.6 with the soft 0.2 lookup; 1.8 was tuned on the sharp one.)
        // (2.6 until QC round 10: the ring read faint; watervar6 r6a: water box sd 14.2 -> 16.7 vs F000 15.5.)
        uRippleShade: { value: 3.1 },
        uFog: shared.uFog,
        uFogColor: shared.uFogColor,
        uOrbCenter: shared.uOrbCenter,
        uOrbGlow: shared.uOrbGlow,
        ...occlusion,
        ...mirrorUniforms,
      },
    });
    const near = new THREE.Mesh(quad(WATER.near.min, WATER.near.max, WATER.level, 1), this.material);
    // The Blender planes overlap by ~3 m; trim the far one so they never z-fight.
    const farMax: THREE.Vector3Tuple = [WATER.far.max[0], WATER.far.max[1], Math.min(WATER.far.max[2], WATER.near.min[2])];
    const far = new THREE.Mesh(quad(WATER.far.min, farMax, WATER.far.min[1], 1), this.material);
    near.name = "water-near";
    far.name = "water-far";
    this.group.add(near, far);
    // The r12 lake is drawn after the environment's opaque meshes in the same pass (same image: opaque, depth-tested): the
    // lake under the near rocks and floes is then rejected by the depth test before its shader runs (the plate lake keeps
    // the default order; `?lkorder=0` restores it for r12).
    if (opts.mirror?.r12 && (typeof location === "undefined" || new URLSearchParams(location.search).get("lkorder") !== "0")) {
      near.renderOrder = 1;
      far.renderOrder = 1;
    }
    if (walkHalf) {
      const wq = typeof location !== "undefined" ? Number(new URLSearchParams(location.search).get("lkwdiv")) : 0;
      if (wq >= 1 && wq <= 8) this.walkDiv = wq;
      const wd = { ...defines, LK_WALKPASS: "" };
      delete (wd as Record<string, string>).LK_HALF;
      delete (wd as Record<string, string>).LK_CACHE;
      // Same uniforms object: every per-frame value the water gets, the walk pass gets.
      this.walkMaterial = new THREE.ShaderMaterial({
        name: "rx-water-walk",
        vertexShader: WATER_VERT,
        fragmentShader: WATER_FRAG,
        defines: wd,
        uniforms: this.material.uniforms,
        depthTest: false,
        depthWrite: false,
      });
      this.walkTarget = new THREE.WebGLRenderTarget(2, 2, {
        type: THREE.HalfFloatType,
        format: THREE.RGBAFormat,
        depthBuffer: false,
        generateMipmaps: false,
        minFilter: THREE.LinearFilter,
        magFilter: THREE.LinearFilter,
        colorSpace: THREE.LinearSRGBColorSpace,
      });
      this.material.uniforms.uLkWalk.value = this.walkTarget.texture;
      this.walkScene = new THREE.Scene();
      for (const m of [near, far]) {
        const w = new THREE.Mesh(m.geometry, this.walkMaterial);
        w.frustumCulled = false;
        this.walkScene.add(w);
      }
      if (lkCache) {
        // The cache pass: the same shader up to the reflection term (LK_CACHEPASS), full resolution, same uniforms.
        const cd = { ...defines, LK_CACHEPASS: "" };
        delete (cd as Record<string, string>).LK_CACHE;
        this.cacheMaterial = new THREE.ShaderMaterial({
          name: "rx-water-cache",
          vertexShader: WATER_VERT,
          fragmentShader: WATER_FRAG,
          defines: cd,
          uniforms: this.material.uniforms,
          depthTest: false,
          depthWrite: false,
        });
        // Full float: a half-float cache rounded the term once more than the computed path (1-ulp differences in ~10 % of the
        // lake pixels after the later shading). Float targets are renderable wherever the heightfield (LakeHeight) is.
        this.cacheTarget = new THREE.WebGLRenderTarget(2, 2, {
          type: THREE.FloatType,
          format: THREE.RGBAFormat,
          depthBuffer: false,
          generateMipmaps: false,
          minFilter: THREE.NearestFilter,
          magFilter: THREE.NearestFilter,
          colorSpace: THREE.LinearSRGBColorSpace,
        });
        this.material.uniforms.uLkCache.value = this.cacheTarget.texture;
        this.cacheScene = new THREE.Scene();
        for (const m of [near, far]) {
          const c = new THREE.Mesh(m.geometry, this.cacheMaterial);
          c.frustumCulled = false;
          this.cacheScene.add(c);
        }
      }
    }
  }

  /** Frame budget (LK_CACHE): the reflection term cached while the camera stands still, its target and scene. */
  private cacheMaterial?: THREE.ShaderMaterial;
  private cacheTarget?: THREE.WebGLRenderTarget;
  private cacheScene?: THREE.Scene;

  /**
   * Lake v4 frame budget on (LK_WALKREPROJ, `?lkperf` not 0): the engine's LakeSchedule decides when the mirror, the walk
   * and the cache are drawn.
   */
  scheduled = false;

  /** True when the reflection term can be cached (r12 v4 with the walk pass, `?lkcache` not 0). */
  get hasCache() {
    return !!this.cacheTarget;
  }

  /**
   * Draws the reflection term (without the ring waves' bend) for the frame's camera into the cache (LakeSchedule: once the
   * camera stands still, again after it drifted ~0.1 px, the DOF inputs changed or the mirror was redrawn).
   */
  renderCache(renderer: THREE.WebGLRenderer, camera: THREE.Camera) {
    if (!this.cacheTarget || !this.cacheScene) return;
    const prev = renderer.getRenderTarget();
    const prevAuto = renderer.autoClear;
    renderer.getClearColor(this.walkPrevClear);
    const prevAlpha = renderer.getClearAlpha();
    renderer.autoClear = false;
    renderer.setRenderTarget(this.cacheTarget);
    renderer.setClearColor(0x000000, 0);
    renderer.clear(true, false, false);
    renderer.render(this.cacheScene, camera);
    renderer.setRenderTarget(prev);
    renderer.setClearColor(this.walkPrevClear, prevAlpha);
    renderer.autoClear = prevAuto;
  }

  /** The water reads the cache this frame (true) or computes the term (false). */
  setCacheOn(on: boolean) {
    const u = this.material.uniforms.uLkCacheOn;
    if (u) u.value = on ? 1 : 0;
  }

  /** Lake v4 (LK_HALF): the half-resolution walk term's own target and scene. */
  private walkMaterial?: THREE.ShaderMaterial;
  private walkTarget?: THREE.WebGLRenderTarget;
  private walkScene?: THREE.Scene;
  private walkPrevClear = new THREE.Color();

  /**
   * Walk target size divisor: a quarter of the main target's size (rb/v4q4 vs per-pixel and half: the same columns at rest
   * and in the hold; lab `?lkwdiv=`).
   */
  walkDiv = 4;

  /** The main HDR target's size (px): the walk target is 1 / walkDiv of it. */
  setWalkSize(width: number, height: number) {
    if (!this.walkTarget) return;
    const k = this.walkDiv;
    this.walkTarget.setSize(Math.max(1, Math.ceil(width / k)), Math.max(1, Math.ceil(height / k)));
    (this.material.uniforms.uLkWalkInv.value as THREE.Vector2).set(1 / Math.max(1, width), 1 / Math.max(1, height));
    // The cache is read per pixel (texelFetch at gl_FragCoord): the main target's own size.
    this.cacheTarget?.setSize(Math.max(1, width), Math.max(1, height));
  }

  /**
   * Draws the walk term (the floes', rocks', shore's and icebergs' faces the pixel's low rays meet) at half resolution with
   * the frame's camera. Static scene and bump: only needed when the camera moved (the lake mirror rendered this frame).
   */
  renderWalk(renderer: THREE.WebGLRenderer, camera: THREE.Camera) {
    if (!this.walkTarget || !this.walkScene) return;
    const prev = renderer.getRenderTarget();
    const prevAuto = renderer.autoClear;
    renderer.getClearColor(this.walkPrevClear);
    const prevAlpha = renderer.getClearAlpha();
    renderer.autoClear = false;
    renderer.setRenderTarget(this.walkTarget);
    renderer.setClearColor(0x000000, 0);
    renderer.clear(true, false, false);
    renderer.render(this.walkScene, camera);
    // LK_WALKREPROJ: the water reads the walk through the view-projection it was drawn with (render() updated the inverse).
    const vp = this.material.uniforms.uLkWalkVP?.value as THREE.Matrix4 | undefined;
    vp?.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
    renderer.setRenderTarget(prev);
    renderer.setClearColor(this.walkPrevClear, prevAlpha);
    renderer.autoClear = prevAuto;
  }

  disposeWalk() {
    this.walkTarget?.dispose();
    this.walkMaterial?.dispose();
    this.cacheTarget?.dispose();
    this.cacheMaterial?.dispose();
  }

  /** Fires a travelling ring from the ripple centre. */
  impulse(time: number, amplitude = 0.05, speed = 3.2, width = 0.9) {
    this.material.uniforms.uImpulse.value.set(time, amplitude, speed, width);
  }
}
