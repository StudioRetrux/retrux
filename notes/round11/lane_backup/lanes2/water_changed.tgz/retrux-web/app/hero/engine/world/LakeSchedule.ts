import * as THREE from "three";
import type { LakeMirror } from "./LakeMirror";
import type { Water } from "./Water";

/**
 * Lake v4 frame budget (WATER lane, round 11 P2b): which of the lake's own passes run on this frame.
 *
 * The water's reflection term (Water.ts lkReflect4) reads what three passes drew before the main pass: the lake mirror (the
 * scene from the mirrored camera), the walk (the low rays' faces, a quarter-size screen target) and, while the camera stands
 * still, the term itself cached per pixel (Water.renderCache). The water looks the mirror up through the matrices the mirror
 * was drawn with, and the walk at the lake point's place in the walk's own frame (LK_WALKREPROJ), so both stay exact when
 * they were drawn a frame earlier or before a pure turn of the camera. Only the cache is tied to the screen.
 *   - Moving camera (pointer orbit, the hold dolly, the release): the term is computed every frame; the mirror and the walk
 *     are redrawn on alternate frames (a jump of more than 20 cm or 1 deg in one frame, e.g. a debug pose, redraws both;
 *     `?lkamort=0`: both every frame).
 *   - Still camera (rest, the sustained hold; the handheld drift turns it by up to ~0.0002 deg per frame): at most one pass
 *     per frame: the mirror or the walk a motion left behind, then the cache, which the water reads from then on. The cache is
 *     redrawn once the camera has drifted 0.003 deg or moved 0.5 mm from its pose (~0.1 px) or the DOF inputs changed; the
 *     mirror every 8 frames (the clouds drift), the cache on the frame after.
 *   - After a resize (new, empty targets) the mirror and the walk are drawn at once.
 */

/** Cache tolerance: (0.5 mm)^2 and 1 - |q.q'| for 0.003 deg (~0.09 px at the rest framing, 0.033 deg per px). */
const CACHE_POS2 = 2.5e-7;
const CACHE_ROT = 3.4e-10;
/** Settled (per frame): under 0.05 mm and 0.0004 deg (twice the handheld drift's fastest turn): the cache lasts >= 7 frames. */
const SETTLED_POS2 = 2.5e-9;
const SETTLED_ROT = 6.1e-12;
/** A jump (per frame): over 20 cm or 1 deg redraws the mirror and the walk together. */
const JUMP_POS2 = 0.04;
const JUMP_ROT = 3.81e-5;
/** The mirror and the walk count as left behind 2 mm away from the camera (still state). */
const STALE_POS2 = 4e-6;
/**
 * Frames between mirror redraws while the camera stands still: the live cloud cards drift up to ~0.1 m/s at 80-130 m
 * (PlateEnvironment CLOUD_VERT), ~1.7 px/s on screen, so their reflections step <= 0.25 px (30 frames: 0.85 px steps).
 */
const CLOUD_FRAMES = 8;

export class LakeSchedule {
  /** Redraw the mirror and the walk on alternate frames while the camera moves (`?lkamort=0`: both every frame). */
  amortize = true;
  /** Read the cached term while the camera stands still (false when the water has no cache: `?lkcache=0`). */
  cache = true;
  /** (lab) passes drawn and frames that read the cache. */
  readonly counts = { frames: 0, mirror: 0, walk: 0, cache: 0, cacheOn: 0 };
  private lastPos = new THREE.Vector3(Infinity, 0, 0);
  private lastQuat = new THREE.Quaternion();
  private mirrorPos = new THREE.Vector3(Infinity, 0, 0);
  private walkPos = new THREE.Vector3(Infinity, 0, 0);
  private cachePos = new THREE.Vector3(Infinity, 0, 0);
  private cacheQuat = new THREE.Quaternion();
  private cacheKey = [NaN, NaN, NaN];
  private cacheValid = false;
  /** The mirror or the walk was redrawn after the cache. */
  private cacheDirty = false;
  /** The mirror was redrawn for a new camera place after the walk. */
  private walkDirty = true;
  private mirrorAge = 0;
  private parity = false;
  /** Startup or resize: the mirror and the walk are drawn on the next frame. */
  private fresh = true;

  constructor(
    private readonly mirror: LakeMirror,
    private readonly water: Water,
  ) {
    this.cache = water.hasCache;
  }

  /** New, empty targets (resize): the mirror and the walk are drawn on the next frame, the cache after them. */
  invalidate() {
    this.fresh = true;
    this.cacheValid = false;
  }

  /**
   * Draws this frame's lake passes before the main pass. `focus`, `hold`, `blur` = the DOF inputs of the water (uFocusDist,
   * uHold, uDofBlur): the cached term holds for one set of them.
   */
  frame(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.PerspectiveCamera,
    level: number,
    layer: number,
    setPass: (on: boolean) => void,
    focus: number,
    hold: number,
    blur: number,
  ) {
    const p = camera.position;
    const q = camera.quaternion;
    const c = this.counts;
    c.frames++;
    const dPos = p.distanceToSquared(this.lastPos);
    const dRot = 1 - Math.abs(q.dot(this.lastQuat));
    this.lastPos.copy(p);
    this.lastQuat.copy(q);
    this.mirrorAge++;
    const drawMirror = () => {
      this.mirror.render(renderer, scene, camera, level, layer, setPass, true);
      this.mirrorPos.copy(p);
      this.mirrorAge = 0;
      c.mirror++;
    };
    const drawWalk = () => {
      this.water.renderWalk(renderer, camera);
      this.walkPos.copy(p);
      this.walkDirty = false;
      c.walk++;
    };
    let cacheOn = false;
    if (this.fresh || dPos > JUMP_POS2 || dRot > JUMP_ROT) {
      drawMirror();
      drawWalk();
      this.fresh = false;
      this.cacheValid = false;
    } else if (dPos > SETTLED_POS2 || dRot > SETTLED_ROT) {
      // Moving (or settling): the term is computed by the water this frame.
      this.cacheValid = false;
      if (!this.amortize) {
        drawMirror();
        drawWalk();
      } else if (this.parity) {
        drawMirror();
        this.walkDirty = true;
      } else drawWalk();
      this.parity = !this.parity;
    } else {
      const k = this.cacheKey;
      const cacheGood =
        this.cache &&
        this.cacheValid &&
        // (Tolerances, not equality: a settled spring still creeps by ~1e-8 m per frame. 1 mm of focus distance or 0.001 of
        // the hold share moves the lake's DOF footprint by nothing visible.)
        Math.abs(k[0] - focus) < 1e-3 &&
        Math.abs(k[1] - hold) < 1e-3 &&
        k[2] === blur &&
        p.distanceToSquared(this.cachePos) <= CACHE_POS2 &&
        1 - Math.abs(q.dot(this.cacheQuat)) <= CACHE_ROT;
      if (p.distanceToSquared(this.mirrorPos) > STALE_POS2) {
        drawMirror();
        this.walkDirty = true;
        this.cacheDirty = true;
      } else if (this.walkDirty || p.distanceToSquared(this.walkPos) > STALE_POS2) {
        drawWalk();
        this.cacheDirty = true;
      } else if (this.mirrorAge > CLOUD_FRAMES) {
        // The clouds' reflections (before the cache, so a cache redrawn often cannot starve it): the cache, still right for
        // this pose, is read once more and redrawn on the next frame.
        drawMirror();
        this.cacheDirty = true;
        cacheOn = cacheGood;
      } else if (this.cache && (!cacheGood || this.cacheDirty)) {
        this.water.renderCache(renderer, camera);
        this.cachePos.copy(p);
        this.cacheQuat.copy(q);
        k[0] = focus;
        k[1] = hold;
        k[2] = blur;
        this.cacheValid = true;
        this.cacheDirty = false;
        cacheOn = true;
        c.cache++;
      } else cacheOn = cacheGood;
    }
    if (cacheOn) c.cacheOn++;
    this.water.setCacheOn(cacheOn);
  }
}
